# drift.py README

## 简介
`drift.py` 用于在线数据漂移检测与模型增量训练。它通过定时任务拉取数据库新数据、进行漂移检测（默认 KS），并在检测到显著漂移时触发模型重训与入库。

## 适用场景
- 生产环境中模型需长期在线更新
- 数据分布随时间变化，需要漂移监控
- 需要保留模型历史与预测表现记录

## 运行流程（概览）
1. 定时任务触发，拉取最新数据
2. 更新滑动窗口
3. 预处理特征并进行漂移检测
4. 根据漂移结果训练新模型并写入数据库
5. 记录漂移指标与预测历史

## 依赖
Python 包：
- pandas, numpy, scikit-learn, scipy
- alibi-detect
- apscheduler
- catboost
- matplotlib, seaborn, pyyaml

项目内部模块：
- `utils.logging_setup`
- `database.base`
- `data_utils.*`

## 配置说明
配置文件读取自 `config/config.yaml`，主要字段包含：
- `COMMON`: 模型参数、特征配置、漂移阈值、滑窗大小等
- `DEV/PROD`: 数据库连接与定时任务间隔（`interval`）

常用配置项（`COMMON`）：
- `drift_threshold`: 漂移阈值（KS 距离）
- `train_size`: 滑动窗口大小
- `buffer_threshold`: 触发训练的最小新增数据量
- `list_category`: 类别特征列表（漂移检测时排除）
- `model_param`: 模型超参
- `fix_feature_flag`: 是否固定特征维度
- `target`: 目标列索引或名称
- `model_version`: 当前模型版本号
- `pre_process`: 是否关联前站数据

## 使用方法
在项目根目录执行：
```bash
python drift.py --TLF_TEST DEV
```
切换为生产环境：
```bash
python drift.py --TLF_TEST PROD
```

## 关键类与函数

### DataMonitorAndTrainer
核心监控与训练类，负责调度、漂移检测与模型更新。

初始化参数：
- `config`: 业务配置字典（来自 `COMMON`）
- `db_config`: 数据库连接配置
- `window_size`: 滑动窗口大小（默认 100）
- `batch_size`: 触发训练的新数据量阈值（默认 30）
- `interval`: 定时任务间隔（分钟）
- `target`: 目标字段索引或列名
- `k_fold`: 交叉验证折数
- `model_param`: 模型超参
- `list_category`: 类别特征列表（漂移检测时排除）
- `layer_info`: 工序/产品/模型元信息
- `fix_feature_flag`: 是否固定特征维度
- `last_check_time`: 上次拉取时间（用于增量拉取）

核心方法（简述）：
- `fetch_new_data(...) -> DataFrame`
  - 从数据库拉取 `last_check_time` 之后的新增数据
  - 关键参数：`ope_no`, `tool_type`, `recipe_short`, `product_id`,
    `fab_id`, `dcitem`, `met_no`, `train_size`, `buffer_threshold`,
    `test_online`, `pre_process_info`, `version`
  - 支持前站数据关联（通过 `wafer_id`）
- `update_data_window(new_data)`
  - 维护滑动窗口（FIFO），只保留最近 `window_size` 条记录
- `calculate_feature_drift(current_features, feature_names_, use_fixed_reference) -> dict`
  - 漂移检测入口，默认 KS；其他算法可按需启用
  - 返回字段：`wasserstein`, `ks`, `lsdd`, `iforest`, `status`, `is_drift`
- `train_model()`
  - 预测离线/在线/漂移模型性能
  - 训练新模型并入库，同时保存预测与漂移历史
- `monitor_and_train(config)`
  - 定时任务入口：拉数 -> 更新窗口 -> 漂移检测 -> 训练
- `shutdown()`
  - 停止调度器

内部辅助方法：
- `normalize(data, reset)`
  - Z-score 标准化；`reset=True` 时重新 fit
- `_handle_missing_values(df, data_type)`
  - 缺失值处理：缺失率>20%直接删列，否则用中位数填充
- `_preprocess_data(df, feature_names_, data_type)`
  - 特征筛选、数值转换、缺失处理
- `_prepare_for_drift_detection(ref_df, current_df)`
  - 对齐特征、转 float、标准化
- `_calculate_ks_drift(ref_data, current_data)`
  - KS 漂移检测
- `_calculate_wasserstein(ref_data, current_data)`
  - Wasserstein 距离
- `_calculate_lsdd_drift(ref_data, current_data)`
  - LSDD 漂移检测
- `_calculate_iforest_drift(ref_data, current_data)`
  - IsolationForest 异常比例

### split_dataset(old_data, new_data) -> (train_df, test_df)
数据集划分策略，当前使用 8:2 随机划分（可按需改为时间序列或混合策略）。

## 输出与文件
运行过程中会生成：
- `r2_history_compare_{drift_threshold}.csv`
- `pred_history_compare_{drift_threshold}.csv`

## 注意事项
- 数据库连接与表结构需匹配 `DatabaseHandler` 的预期
- 默认只启用 KS 检测，其他算法需在代码中取消注释
- LSDD/IsolationForest 可能带来额外性能开销
