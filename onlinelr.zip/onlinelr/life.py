"""
life.py - 基于数据生命周期的在线增量学习模块

核心思想：
    采用"贡献度淘汰"策略管理训练数据，区别于传统的"时间淘汰"策略。
    通过计算每个样本对模型的贡献度（以预测误差衡量），淘汰低贡献样本，
    保留高质量训练数据，从而提升模型预测性能。

主要功能：
    1. 定时从数据库获取增量数据
    2. 维护双窗口数据管理（时间窗口 + 贡献度窗口）
    3. 基于样本损失的贡献度评估与数据淘汰
    4. 自动化模型训练与性能监控
"""

import argparse
import os
import traceback
from datetime import datetime, timedelta
import time
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score
import yaml
import logging
from apscheduler.schedulers.background import BackgroundScheduler
from typing import Tuple
from pathlib import Path
import sys

# 将父目录加入搜索路径，以便导入自定义模块
sys.path.append(str(Path(__file__).parent.parent))
from database.base import DatabaseHandler
from data_utils.load_config import load_yaml
from data_utils.data_loader import getDataOnline, getDataOnlinePreProcess
from data_utils.model_selection_mul import getBestModel_multi_model
from data_utils.model_selection import getBestModel, getBestModel_init
from data_utils.predict import model_predict
from data_utils.data_filter import align_old_model_with_feature
from utils.logging_setup import configure_logger

# 关闭 APScheduler 的 warning 日志，避免冗余输出
logging.getLogger("apscheduler.scheduler").setLevel(logging.ERROR)
logging.getLogger("apscheduler.executors.default").setLevel(logging.ERROR)

def split_dataset(old_data, new_data) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    数据集划分函数
    
    采用随机划分策略，将新旧数据合并后按 8:2 比例划分训练集和测试集。
    使用固定随机种子(42)确保结果可复现。
    
    Args:
        old_data: 历史数据（滑动窗口中的旧数据）
        new_data: 新到达的增量数据
        
    Returns:
        train: 训练集（80%）
        test: 测试集（20%）
    """
    data = pd.concat((old_data, new_data))
    train, test = train_test_split(data, test_size=0.2, random_state=42)
    return train, test



class DataMonitorAndTrainer:
    """
    数据生命周期管理与在线模型训练器
    
    该类实现了一个完整的在线学习系统，核心特点是采用"贡献度淘汰"策略：
    - 维护两个数据窗口：时间窗口（FIFO）和贡献度窗口（按损失淘汰）
    - 通过计算样本预测误差评估贡献度，淘汰对模型帮助最小的样本
    - 自动调度数据获取和模型训练任务
    """
    
    def __init__(self, config, db_config, window_size: int = 100, batch_size: int = 100, interval=1,
                 target=0,
                 k_fold=5,
                 model_param={},
                 model_param_online={},
                 list_category=[],
                 layer_info={},
                 fix_feature_flag=True,
                 last_check_time=datetime.now()):
        """
        初始化数据监控和训练器
        
        Args:
            config: 配置字典，包含运行参数
            db_config: 数据库连接配置
            window_size: 滑动窗口大小，决定保留多少条历史数据用于训练
            batch_size: 触发训练的新数据量阈值，累积到此数量时开始训练
            interval: 定时任务执行间隔（分钟）
            target: 目标变量索引
            k_fold: 交叉验证折数
            model_param: 离线模型超参数
            model_param_online: 在线模型超参数
            list_category: 类别型特征列表
            layer_info: 层级信息（工序、产品等）
            fix_feature_flag: 是否固定特征
            last_check_time: 上次数据检查时间
        """
        # ==================== 漂移检测相关（保留接口，本模块未启用） ====================
        self.drift_history = {
            'wasserstein': [0],
            'ks': [0],
            'lsdd': [0],
            'iforest': [0],
            'timestamps': [0]
        }
        self.preprocessed_reference = None
        self.detection_count = 0
        self.fixed_reference = None
        self.processed_current = None
        
        # ==================== 运行状态标记 ====================
        self.is_first_run = True      # 首次运行标记，用于初始化模型
        self.first_drift_flag = True
        self.first_scaler = True
        self.force_update_counter = 0
        self.fixed_ref = False
        self.force_update = False
        
        # ==================== 模型性能追踪 ====================
        # 存储各模型的R²历史，用于对比不同策略的效果
        self.offline_model_predict_r2 = []    # 离线模型（数据库初始模型）的R²
        self.actual_model_predict_r2 = []     # 在线实时更新模型的R²（保留接口）
        self.r2_history_drift = []            # 漂移检测模型的R²（保留接口）
        self.r2_history_life = []             # 生命周期模型（贡献度淘汰）的R²
        
        self.test_data_cleaned = None  # 经过贡献度淘汰后的训练数据
        self.n_update = 0

        # ==================== 模型存储 ====================
        self.life_model = None          # 生命周期策略训练的模型
        self.life_x_mean_std = None     # 生命周期模型的标准化参数
        self.models = []                # 多模型存储（预留）
        self.model_weights = []         # 模型权重（预留）
        self.offline_model = None       # 离线基准模型
        self.offline_x_mean_std = None  # 离线模型标准化参数
        
        self.new_data = None            # 待处理的新数据缓存
        self.view_flage = False
        self.scaler = StandardScaler()

        # ==================== 滑动窗口配置 ====================
        self.window_size = window_size
        self.batch_size = batch_size
        
        # 时间淘汰窗口：保留最新的 window_size 条数据（FIFO策略）
        self.data_window = pd.DataFrame()
        
        # 贡献度淘汰窗口：根据样本损失淘汰低贡献数据
        # 核心思想：预测误差小的样本对模型贡献低，应优先淘汰
        self.data_window_contribution = pd.DataFrame()
        self.loss_col = "sample_loss"   # 损失列名
        
        self.new_data_length = 0        # 新数据累积量
        self.last_check_time = last_check_time
        
        # ==================== 模型训练参数 ====================
        self.target = target
        self.k_fold = k_fold
        self.list_category = list_category
        self.layer_info = layer_info
        self.model_param = model_param
        self.model_param_online = model_param_online
        self.fix_feature = fix_feature_flag

        # ==================== 定时调度器 ====================
        self.scheduler = BackgroundScheduler()
        self.model = None
        self.db_handler = DatabaseHandler(db_config=db_config)

        # 添加定时任务：每隔 interval 分钟执行一次 monitor_and_train
        self.scheduler.add_job(
            self.monitor_and_train,
            'interval',
            minutes=interval,
            next_run_time=datetime.now(),   # 立即开始首次执行
            end_date=datetime.now() + timedelta(hours=30),  # 30小时后自动停止
            kwargs={'config': config}
        )
        self.scheduler.start()

        # ==================== 训练数据缓存 ====================
        self.last_x_train = None
        self.last_y_train = None
        self.last_x_val = None
        self.last_y_val = None
        self.config = config
        self.history_predict_data = pd.DataFrame()

        # ==================== 预测结果记录 ====================
        # 用于对比分析不同模型的预测效果
        self.online_wafer_ids = []              # 处理过的wafer_id列表
        self.y_true = []                        # 真实量测值
        self.actual_model_predict_value = []    # 在线模型预测值
        self.drift_model_predict_value = []     # 漂移模型预测值
        self.offline_model_predict_value = []   # 离线模型预测值
        self.life_model_predict_value = []      # 生命周期模型预测值



    def fetch_new_data(self, ope_no, tool_type, recipe_short, product_id, fab_id, dcitem, met_no, train_size,
                       buffer_threshold, test_online, pre_process_info, version) -> pd.DataFrame:
        """
        从数据库获取增量数据
        
        该方法实现了完整的数据获取流程：
        1. 根据 last_check_time 增量查询当站数据
        2. 如配置了前站信息，获取前站预处理数据并通过 wafer_id 合并
        3. 对类别特征进行空值检查，剔除含空值的异常样本
        
        Args:
            ope_no: 工序编号
            tool_type: 机台类型
            recipe_short: 配方简称
            product_id: 产品ID
            fab_id: 工厂ID
            dcitem: 量测参数
            met_no: 量测编号
            train_size: 训练数据量
            buffer_threshold: 缓冲阈值
            test_online: 在线测试开关
            pre_process_info: 前站预处理配置
            version: 模型版本号
            
        Returns:
            处理后的新数据DataFrame
        """
        logger.info(f"拉取<{self.last_check_time}>以后更新的数据")
        print(f"test_online{test_online}")

        # 打印传入 getDataOnline 的参数信息
        print("getDataOnline 参数信息:")
        print(f"  ope_no: {ope_no}")
        print(f"  tool_type: {tool_type}")
        print(f"  recipe_short: {recipe_short}")
        print(f"  product_id: {product_id}")
        print(f"  fab_id: {fab_id}")
        print(f"  dcitem: {dcitem}")
        print(f"  met_no: {met_no}")
        print(f"  train_size: {train_size}")
        print(f"  buffer_threshold: {buffer_threshold}")
        print(f"  test_online: {test_online}")
        print(f"  version: {version}")
        print(f"  update_time: {self.last_check_time}")

        # 1. 获取原始数据
        new_data = getDataOnline(
            db_handler=self.db_handler,
            ope_no=ope_no,
            tool_type=tool_type,
            recipe_short=recipe_short,
            product_id=product_id,
            fab_id=fab_id,
            dcitem=dcitem,
            met_no=met_no,
            train_size=train_size,
            buffer_threshold=buffer_threshold,
            test_online=test_online,
            version=version,
            update_time=self.last_check_time
        )
        self.db_handler.first_load_data = False
        print(f"数据版本号版本号:{version}")
        logger.info(f"成功拉取当站数据{len(new_data)} 条数据")
        # logger.info(f"成功拉取当站数据{len(new_data)} 条数据")
        if len(new_data) ==0:
            time.sleep(3600)

        # 2. 获取前站预处理数据
        if pre_process_info and len(new_data) > 0:
            pre_new_data = getDataOnlinePreProcess(
                db_handler=self.db_handler,
                ope_no=pre_process_info["OPE_NO"][0],
                tool_type=pre_process_info["TOOL_TYPE"][0],
                product_id=pre_process_info["PRODUCT"],
                fab_id=pre_process_info["FAB_ID"],
                dcitem=pre_process_info["DCITEM"][0],
                met_no=pre_process_info["MET_NO"][0],
                wafer_list=new_data["wafer_id"].tolist(),
                update_time=self.last_check_time
            )
            logger.info(f"成功拉取前站预处理数据{len(pre_new_data)} 条数据")

            if len(pre_new_data) > 0:
                # 3. 合并数据并处理
                new_data = pd.merge(
                    new_data,
                    pre_new_data,
                    on='wafer_id',
                    how='left',
                    suffixes=("", "_pre")
                )

                # 移除合并产生的冗余列
                if "update_time_pre" in new_data.columns:
                    new_data = new_data.drop(columns=["update_time_pre"])

                # 检查合并后的数据完整性
                inner_join_data = pd.merge(
                    new_data, pre_new_data,
                    on='wafer_id', how='inner'
                )
                logger.info(f"当站与前站数据差距{len(new_data) - len(inner_join_data)} 条数据")

        # 4. 类别特征空值处理
        # 类别特征（如机台ID、配方等）的空值会导致编码失败，必须在训练前剔除
        if hasattr(self, 'list_category') and self.list_category:
            # 计算原始数据量
            original_count = len(new_data)

            # 创建类别特征缺失标记
            for col in self.list_category:
                if col in new_data.columns:
                    # 标记空值点
                    new_data[f"{col}_is_missing"] = new_data[col].isna()

            # 确定需要检查的类别特征列（实际存在于数据中的）
            valid_cat_cols = [col for col in self.list_category if col in new_data.columns]

            if valid_cat_cols:
                # 创建综合缺失标记（任一类别特征缺失即为True）
                new_data['any_cat_missing'] = new_data[[f"{col}_is_missing" for col in valid_cat_cols]].any(axis=1)

                # 分离有效数据和缺失数据
                valid_data = new_data[~new_data['any_cat_missing']]
                missing_data = new_data[new_data['any_cat_missing']]

                # 记录剔除信息
                missing_count = len(missing_data)
                logger.warning(
                    f"剔除{missing_count}条含空类别特征的数据 "
                    f"(占比:{missing_count / max(1, original_count):.1%}) "
                    f"剩余数据量:{len(valid_data)}"
                )

                # 打印详细的缺失情况
                if not missing_data.empty:
                    # 汇总各特征的缺失情况
                    missing_stats = {}
                    for col in valid_cat_cols:
                        missing_stats[col] = missing_data[col].isna().sum()

                    logger.info(f"各特征缺失统计: {missing_stats}")

                    # 记录被剔除的wafer_id（前10条）
                    sample_ids = missing_data['wafer_id'].head(10).tolist()
                    logger.debug(f"部分被剔除的wafer_id: {sample_ids}")

                # 移除临时列并返回有效数据
                new_data = valid_data.drop(
                    columns=[f"{col}_is_missing" for col in valid_cat_cols] + ['any_cat_missing'],
                    errors='ignore'
                )


            else:
                logger.warning("配置的类别特征在当前数据中均不存在")


        else:
            logger.error("未定义类别特征列表list_category，跳过空值检查")

        # 5. 最终数据量检查
        if len(new_data) < self.batch_size:
            self.view_flage = True
            logger.info(f"新数据量不足阈值({self.batch_size})，当前:{len(new_data)}")

        return new_data
        
    def update_data_window(self, new_data: pd.DataFrame):
        """
        更新双数据窗口
        
        该方法维护两个独立的数据窗口，采用不同的淘汰策略：
        
        1. 时间淘汰窗口 (data_window)：
           - 采用 FIFO（先进先出）策略
           - 保留最新的 window_size 条数据
           - 简单高效，但无法区分数据质量
           
        2. 贡献度淘汰窗口 (data_window_contribution)：
           - 基于样本预测误差评估贡献度
           - 淘汰模型能准确预测的样本（损失小 = 贡献低）
           - 保留"困难样本"有助于模型学习边界情况
        
        Args:
            new_data: 新到达的增量数据
        """
        n = len(new_data)

        # ==================== 1. 更新时间淘汰窗口 ====================
        # FIFO策略：新数据入队，超出窗口大小时丢弃最老的数据
        self.data_window = pd.concat([self.data_window, new_data], ignore_index=True)
        if len(self.data_window) > self.window_size:
            self.data_window = self.data_window.iloc[-self.window_size:]
        logger.info(f"原时间窗口更新：当前大小{len(self.data_window)}")

        # ==================== 2. 更新贡献度淘汰窗口 ====================
        if self.is_first_run:
            # 首次运行时无历史损失信息，直接添加数据
            self.data_window_contribution = pd.concat(
                [self.data_window_contribution, new_data],
                ignore_index=True
            )
            logger.info(f"首次运行，直接添加新数据 | 当前窗口大小: {len(self.data_window_contribution)}")
            return
        
        # 非首次运行：将清洗后的数据（已剔除低贡献样本）与新数据合并
        self.data_window_contribution = pd.concat(
            [self.test_data_cleaned, new_data],
            ignore_index=True
        )

        # 剔除时间戳类型的列（除 update_time 和类别特征外）
        # 时间戳不能直接用于模型训练，需要提前移除
        timestamp_columns = []
        for col in self.data_window.columns:
            if (pd.api.types.is_datetime64_any_dtype(self.data_window[col]) and 
            col not in self.list_category and
            col != 'update_time'): 
                timestamp_columns.append(col)
        
        if timestamp_columns:
            logger.info(f"排除时间戳类型列: {timestamp_columns}")
            self.data_window = self.data_window.drop(columns=timestamp_columns, errors='ignore')
        else:
             logger.info("数据窗口无时间戳列")

        timestamp_columns_contribution = []
        for col in self.data_window_contribution.columns:
            # 检查是否为时间戳类型且不是类别特征
            if (pd.api.types.is_datetime64_any_dtype(self.data_window_contribution[col]) and 
                col not in self.list_category and
                col != 'update_time'):
                timestamp_columns_contribution.append(col)
        
        if timestamp_columns_contribution:
            logger.info(f"排除时间戳类型列: {timestamp_columns_contribution}")
            self.data_window_contribution = self.data_window_contribution.drop(columns=timestamp_columns_contribution, errors='ignore')
        else:
             logger.info("贡献度窗口无时间戳列")


        logger.info(f"最终窗口大小: {len(self.data_window_contribution)}")

    def train_model(self):
        """
        模型训练主流程
        
        该方法实现了完整的生命周期模型训练逻辑：
        1. 首次运行时初始化离线基准模型
        2. 使用离线模型预测新数据，记录基准R²
        3. 使用生命周期模型预测新数据，评估当前性能
        4. 基于贡献度窗口训练新模型
        5. 计算样本损失，淘汰低贡献样本
        6. 保存预测结果用于后续分析
        """
        # ==================== 首次运行：初始化基准模型 ====================
        if self.is_first_run:
            train_set, test_set = split_dataset(self.data_window[:-self.batch_size],
                                                self.data_window[-self.batch_size:])
            # 训练初始离线模型作为性能基准
            model_off, x_mean_std_offline = getBestModel_init(
                train_set,
                test_set,
                target=self.target,
                k_fold=self.k_fold,
                list_category=self.list_category,
                fix_feature=self.fix_feature,
                model_param=self.model_param_online
            )
            self.offline_model = model_off
            self.offline_x_mean_std = x_mean_std_offline

        # ==================== 非首次运行：评估模型性能 ====================
        else:
            # 使用离线基准模型预测新数据，评估基准性能
            test_data = align_old_model_with_feature(
                self.offline_model, 
                self.data_window[-self.batch_size:].copy(),
                self.offline_x_mean_std
            )

            metrics_old, old_wafer_id, old_real, old_pre, test_feat, test_y_bias = model_predict(
                model=self.offline_model,
                data=test_data,
                standardization=self.offline_x_mean_std,
                list_category=self.list_category,
                target=self.target
            )
            
            # 记录离线模型预测结果，用于与生命周期模型对比
            self.offline_model_predict_value.extend(old_pre)
            self.y_true.extend(old_real)
            self.online_wafer_ids.extend(old_wafer_id)
            self.offline_model_predict_r2.append(metrics_old['r2'])
            logger.info(f"当前数据库中的离线模型预测R2：{metrics_old['r2']}")

            logger.info("使用最新模型预测新到的片")
        ######################################################## 最新的在线模型###################################
        # print("#######在线模型########")
        # if self.is_first_run:
        #     self.newest_model=self.offline_model
        #     self.x_mean_std_newest = self.offline_x_mean_std
        #     train_set, test_set = split_dataset(self.data_window[:-self.batch_size],
        #                                         self.data_window[-self.batch_size:])

        # else:

        #     test_data = align_old_model_with_feature(self.newest_model, self.data_window[-self.batch_size:].copy(),
        #                                                  self.x_mean_std_newest)
        #     logger.info(f"测试数据量为：{len(test_data)}")

        #     metrics_newest, newest_wafer_id, newest_real, newest_pre, test_feat, test_y_bias = model_predict(
        #         model=self.newest_model,
        #         data=test_data,
        #         standardization=self.x_mean_std_newest,
        #         list_category=self.list_category,
        #         target=self.target)




        #     self.actual_model_predict_value.extend(newest_pre)
        #     self.actual_model_predict_r2.append(metrics_newest['r2'])
        #     logger.info(f"当前数据库中的最新模型预测R2：{metrics_newest['r2']}")

        # train_set, test_set = split_dataset(self.data_window[:-self.batch_size], self.data_window[-self.batch_size:])

        # # train_set, test_set = self.train_set.copy(), self.test_set.copy()

        # model, x_mean_std, confidence_param, update_flag, metrics_new = getBestModel(train_set,
        #                                                                              test_set,
        #                                                                              target=self.target,
        #                                                                              k_fold=self.k_fold,
        #                                                                              list_category=self.list_category,
        #                                                                              old_model=self.newest_model,
        #                                                                              fix_feature=self.fix_feature,
        #                                                                              model_param=self.model_param_online)

        # self.newest_model = model
        # self.x_mean_std_newest = x_mean_std

        # ==================== 数据生命周期模型处理 ====================
        # 该模块是本文件的核心创新点：基于贡献度淘汰策略的在线学习
        print("#######数据生命周期########")
        
        if self.is_first_run:
            # 首次运行：用离线模型初始化生命周期模型
            self.life_model = self.offline_model
            self.life_x_mean_std = self.offline_x_mean_std
        else:
            # 使用当前生命周期模型预测新数据，评估贡献度策略的效果
            test_data = align_old_model_with_feature(
                self.life_model, 
                self.data_window[-self.batch_size:].copy(),
                self.life_x_mean_std
            )

            metrics_life, life_wafer_id, life_real, life_pre, test_feat, test_y_bias = model_predict(
                model=self.life_model,
                data=test_data,
                standardization=self.life_x_mean_std,
                list_category=self.list_category,
                target=self.target
            )

            self.life_model_predict_value.extend(life_pre)
            self.r2_history_life.append(metrics_life['r2'])
            logger.info(f"当前数据库中的数据生命周期最新模型预测R2：{metrics_life['r2']}")

        # ==================== 训练新的生命周期模型 ====================
        # 使用贡献度窗口的数据进行训练
        train_set, test_set = split_dataset(
            self.data_window_contribution[:-self.batch_size],
            self.data_window_contribution[-self.batch_size:]
        )

        model, x_mean_std, confidence_param, update_flag, metrics_new = getBestModel(
            train_set,
            test_set,
            target=self.target,
            k_fold=self.k_fold,
            list_category=self.list_category,
            old_model=self.life_model,
            fix_feature=self.fix_feature,
            model_param=self.model_param_online
        )

        confidence_param |= metrics_new

        # 更新生命周期模型
        self.life_model = model
        self.life_x_mean_std = x_mean_std

        # ==================== 贡献度评估与样本淘汰 ====================
        # 核心思想：用新模型预测所有数据，计算每个样本的预测误差
        # 误差小 = 模型已充分学习该模式 = 贡献度低 = 应优先淘汰
        test_data_update = align_old_model_with_feature(model, self.data_window.copy(), x_mean_std)

        metrics_life_update, life_wafer_id_update, life_real_update, life_pre_update, test_feat_update, test_y_bias_update = model_predict(
                model=model,
                data=test_data_update,
                standardization=x_mean_std,
                list_category=self.list_category,
                target=self.target
        )

        # 计算每个样本的损失（均方误差）
        # 损失越小，说明模型对该样本预测越准确，该样本的"边际贡献"越低
        losses = np.square(np.array(life_real_update) - np.array(life_pre_update))
        
        # 找出损失最小的 batch_size 个样本，这些样本将被淘汰
        lowest_loss_indices = np.argsort(losses)[:self.batch_size]

        # 从数据窗口中移除低贡献样本
        self.test_data_cleaned = test_data_update.drop(test_data_update.index[lowest_loss_indices])

        logger.info(f"已剔除{len(lowest_loss_indices)}个损失最低的样本，剩余{len(self.test_data_cleaned)}个样本")
        print(f"剔除的样本索引: {lowest_loss_indices}")


        # ==================== 保存实验结果 ====================
        # 输出文件用于后续分析和对比不同策略的效果
        output_dir = "/ossfs/workspace/vm_Q4/train_Q4/output"
        os.makedirs(output_dir, exist_ok=True)
        
        # 保存R²历史对比：离线模型 vs 生命周期模型
        result_df = pd.DataFrame()
        result_df['offline_model_predict_r2'] = self.offline_model_predict_r2
        result_df['r2_history_life'] = self.r2_history_life
        result_df.to_csv(
            f"{output_dir}/r2_life_{self.config['layer_name']}_{self.batch_size}_{self.window_size}.csv",
            index=None
        )

        # 保存预测值对比：真实值 vs 各模型预测值
        result_df = pd.DataFrame()
        result_df['online_wafer_ids'] = self.online_wafer_ids
        result_df['y_true'] = self.y_true
        result_df['offline_model_predict_value'] = self.offline_model_predict_value
        result_df['life_model_predict_value'] = self.life_model_predict_value
        result_df.to_csv(
            f"{output_dir}/pred_life_{self.config['layer_name']}_{self.batch_size}_{self.window_size}.csv",
            index=None
        )

        logger.info(f"离线r2记录{len(self.offline_model_predict_r2)}{self.offline_model_predict_r2}")
        logger.info(f"生命周期更新r2记录{len(self.r2_history_life)}{self.r2_history_life}")
        logger.info(f"正在跑的实验：{config['layer_name'],config['train_size'],config['buffer_threshold']},脚本：mian_off_on_life.py")

        logger.info("一轮处理结束")
        self.is_first_run = False

    def fetch_and_save_data(self, config):
        """
        获取数据并保存到CSV文件（调试用）
        
        该方法用于首次获取大量数据并缓存到本地，
        后续可通过 load_from_csv() 直接加载，避免重复查询数据库。
        
        Args:
            config: 配置字典
            
        Returns:
            获取到的数据DataFrame
        """
        filename = f"/ossfs/workspace/vm_Q4/train_Q4/data/data_{config['layer_name']}.csv"
        save_path = os.path.join("./data_cache", filename)
        
        # 创建目录（如果不存在）
        os.makedirs("./data_cache", exist_ok=True)
        
        # 获取数据
        print("拉取新数据...")
        new_data = self.fetch_new_data(
            config["siteID"],
            config["tool_type"],
            config["recipe_short"],
            config["product_id"],
            config["fab_id"],
            config["metParamID"],
            config["metID"],
            10000,
            config["buffer_threshold"],
            config["test_online"],
            config["pre_process"],
            config["model_version"]
        )
        
        if not new_data.empty:
            # 保存到CSV
            new_data.to_csv(save_path, index=False, encoding='utf-8-sig')
            print(f"数据已保存到: {save_path}")
            print(f"数据形状: {new_data.shape}")
            print(f"数据时间范围: {new_data['update_time'].min()} - {new_data['update_time'].max()}")
        
        return new_data

    def load_from_csv(self, config):
        """
        从CSV缓存文件加载数据
        
        用于加载之前通过 fetch_and_save_data() 保存的数据，
        避免重复查询数据库，加速实验迭代。
        
        Args:
            config: 配置字典
            
        Returns:
            加载的数据DataFrame，如文件不存在则返回空DataFrame
        """
        filename = f"/ossfs/workspace/vm_Q4/train_Q4/data/data_{config['layer_name']}.csv"
        filepath = os.path.join("./data_cache", filename)
        
        if not os.path.exists(filepath):
            print(f"缓存文件不存在: {filepath}")
            return pd.DataFrame()
        
        try:
            data = pd.read_csv(filepath)
            # data = data[:4260]###################针对G4b_TCP_01_DE

            # 确保update_time是datetime类型
            if 'update_time' in data.columns:
                data['update_time'] = pd.to_datetime(data['update_time'])
            print(f"从缓存加载数据成功: {filepath}")
            print(f"数据形状: {data.shape}")
            if not data.empty:
                print(f"数据时间范围: {data['update_time'].min()} - {data['update_time'].max()}")
            return data
        except Exception as e:
            logger.error(f"加载缓存文件失败: {str(e)}")
            return pd.DataFrame()


    def monitor_and_train(self, config):
        """
        定时调度的核心执行函数
        
        该方法由 APScheduler 周期性调用，实现以下流程：
        1. 首次运行：加载初始数据填充窗口
        2. 后续运行：增量获取新数据
        3. 更新数据窗口（时间窗口 + 贡献度窗口）
        4. 触发模型训练和贡献度评估
        
        Args:
            config: 配置字典
        """
        if self.is_first_run:
            print("首次拉数据")
            
            # self.new_data = self.fetch_and_save_data(config)
            self.new_data = self.load_from_csv(config)
           


            if not self.new_data.empty:
                self.new_data_length = self.new_data.shape[0]
                self.last_check_time = self.new_data["update_time"].max()
                old_check_time = self.new_data["update_time"].min()
                print(f"数据时间{old_check_time}-{self.last_check_time}")
                # 将 self.new_data按照["update_time"]排序
                self.new_data = self.new_data.sort_values(by=["update_time"])
                
                self.new_data = self.new_data[:4260]
                print(f"截取数据量{len(self.new_data)}")
                print("第2001wafer_id:", self.new_data.iloc[2000]['wafer_id'])
    

                #new_data为self.new_data中索引最小的self.window_size条数据
                new_data =self.new_data.iloc[:self.window_size]
                self.new_data = self.new_data.iloc[self.window_size:]
                logger.info(f"数据时间{new_data['update_time'].max()}-{new_data['update_time'].min()}")


        else:
        # new_data为self.new_data中索引最小的self.batch_size条数据
            if len(self.new_data) > self.batch_size:
                
                new_data = self.new_data.iloc[:self.batch_size]
                self.new_data = self.new_data.iloc[self.batch_size:]
                logger.info(f"数据时间{new_data['update_time'].max()}-{new_data['update_time'].min()}")
                print(f"剩下的数据量{len(self.new_data)}")

            else:
                print("数据量不足")
                time.sleep(100000)
                

        try:
        
            self.update_data_window(new_data)

            print(f"抓取{self.new_data_length}条新数据")
                
            self.train_model()
            # self.is_first_run = False
        
                
            


        except Exception as e:
            logger.error(traceback.format_exc())
            logger.error(f"Error in monitoring job: {str(e)}")


    def shutdown(self):
        """
        关闭后台调度器
        
        确保程序退出时正确释放调度器资源，
        避免后台任务继续运行。
        """
        self.scheduler.shutdown()


# ==================== 主程序入口 ====================
if __name__ == "__main__":
    import time
    import os, random, numpy as np
    
    # 设置随机种子，确保实验可复现
    SEED = 42
    os.environ["PYTHONHASHSEED"] = str(SEED)
    random.seed(SEED)
    np.random.seed(SEED)

    # ==================== 命令行参数解析 ====================
    parser = argparse.ArgumentParser(description='数据生命周期在线学习 - 环境切换')
    parser.add_argument('--TLF_TEST', type=str, help='环境选择: DEV/PROD/TLF_TEST', default="TLF_TEST")
    args = parser.parse_args()
    
    # ==================== 加载配置文件 ====================
    # 根据实际需求修改配置文件路径
    config = load_yaml(r'/ossfs/workspace/vm_Q4/config/G4B_TCP_01_DEP.yaml')
    
    # 解析环境配置
    args.env = args.TLF_TEST.upper()
    env_args = config[args.env]
    db_config = env_args["db_info"]
    config = config["COMMON"]
    # ==================== 从配置中提取参数 ====================
    list_category = config['list_category']       # 类别特征列表
    model_config = config['model_param']          # 模型超参数
    logger_path = config['logger_path']           # 日志路径
    buffer_threshold = config['buffer_threshold'] # 触发训练的新数据阈值
    train_size = config['train_size']             # 滑动窗口大小

    # 层级信息：标识具体的工序、产品、机台等
    ope_no = config['siteID']
    tool_type = config['tool_type']
    recipe_short = config['recipe_short']
    product_id = config["product_id"]
    fab_id = config["fab_id"]
    dcitem = config['metParamID']
    met_no = config['metID']
    k_fold = config['k_fold']
    target = config['target']
    layer_name = config['layer_name']
    model_param = config['model_param']
    model_param_online = config['model_param_online']
    fix_feature_flag = config['fix_feature_flag']
    interval = env_args['interval']
    pre_process = config['pre_process']
    
    layer_info = {
        "ope_no": ope_no, "product_id": product_id, "fab_id": fab_id,
        "dcitem": dcitem, "tool_type": tool_type,
        "recipe_short": recipe_short,
        "layer": layer_name, "version": config["model_version"]
    }

    # 配置日志记录器
    logger = configure_logger(log_file=f'{logger_path}')
    # ==================== 创建并启动监控器 ====================
    monitor = DataMonitorAndTrainer(
        config, 
        db_config=db_config, 
        window_size=train_size,           # 滑动窗口大小
        batch_size=buffer_threshold,      # 触发训练的新数据阈值
        interval=interval,                # 定时任务间隔
        k_fold=k_fold,
        target=target,
        list_category=list_category,
        layer_info=layer_info,
        fix_feature_flag=fix_feature_flag,
        model_param=model_param,
        model_param_online=model_param_online,
        last_check_time=datetime(2024, 1, 1, 0, 0, 0)  # 数据起始时间
    )

    logger.info("监控已启动，按 Ctrl+C 停止")
    
    try:
        # 主线程保持运行，等待调度器执行任务
        while True:
            time.sleep(1)
    except (KeyboardInterrupt, SystemExit):
        # 捕获中断信号，优雅关闭
        monitor.shutdown()
