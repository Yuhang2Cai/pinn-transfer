﻿# model.py README

## 简介
`model.py` 用于在线增量训练与评估。它维护时间滑动窗口与“贡献度窗口”，在每次批量数据到达时训练最新模型、评估离线基线模型，并通过多模型加权策略更新生命周期模型，从而在数据分布变化时保持稳定表现。

## 适用场景
- 生产环境需要持续在线更新模型
- 既要保留离线基线效果，又要评估最新模型效果
- 希望通过多模型加权降低单模型漂移风险
- 需要对样本贡献度进行筛选（淘汰低贡献样本）

## 运行流程（概览）
1. 定时任务触发，拉取或读取新数据
2. 更新滑动窗口（时间窗口 + 贡献度窗口）
3. 训练/更新最新模型
4. 多模型加权预测并记录 R2 指标
5. 基于样本损失淘汰低贡献样本
6. 输出预测结果与指标对比文件

## 依赖
Python 包：
- pandas, numpy, scikit-learn
- apscheduler
- pyyaml

项目内部模块：
- `utils.logging_setup`
- `database.base`
- `data_utils.*`

## 配置说明
配置文件通过 `load_yaml` 读取（示例：`/ossfs/workspace/vm_Q4/config/G4B_PCU_10_DEP.yaml`），主要字段包括：
- `COMMON`: 模型参数、特征配置、窗口大小等
- `DEV/PROD/TLF_TEST`: 数据库连接与定时任务间隔（`interval`）

常用配置项（`COMMON`）：
- `train_size`: 时间窗口大小
- `buffer_threshold`: 触发训练的最小新数据量
- `list_category`: 类别特征列表
- `model_param` / `model_param_online`: 模型超参
- `fix_feature_flag`: 是否固定特征维度
- `target`: 目标列索引或名称
- `model_version`: 当前模型版本号
- `pre_process`: 是否关联前站数据

## 使用方法
在项目根目录执行：
```bash
python model.py --TLF_TEST DEV
```
切换为生产环境：
```bash
python model.py --TLF_TEST PROD
```

## 关键类与函数

### DataMonitorAndTrainer
核心调度与训练类，负责数据拉取、窗口维护与模型更新。

初始化参数（核心）：
- `config`: 业务配置（来自 `COMMON`）
- `db_config`: 数据库连接配置
- `window_size`: 时间滑动窗口大小
- `batch_size`: 触发训练的最小新数据量
- `interval`: 定时任务间隔（分钟）
- `target`, `k_fold`
- `list_category`, `layer_info`, `fix_feature_flag`
- `model_param`, `model_param_online`
- `last_check_time`: 增量拉取起点

核心方法（简述）：
- `fetch_new_data(...) -> DataFrame`
  - 从数据库拉取 `last_check_time` 之后的增量数据
  - 支持关联前站数据（按 `wafer_id`）
- `update_data_window(new_data)`
  - 维护时间窗口（FIFO）与贡献度窗口（按损失淘汰）
- `train_model()`
  - 训练最新模型、评估离线模型
  - 多模型加权预测并记录 R2
  - 依据样本损失淘汰低贡献样本
- `monitor_and_train(config)`
  - 定时任务入口：拉取数据 -> 更新窗口 -> 训练
- `fetch_and_save_data(config)` / `load_from_csv(config)`
  - 调试用数据缓存读写
- `shutdown()`
  - 关闭调度器

### split_dataset(old_data, new_data) -> (train_df, test_df)
合并新旧数据后随机按 8:2 划分训练/测试。

## 输出与文件
运行过程中生成：
- `/ossfs/workspace/vm_Q4/train_Q4/output/r2_model_{layer}_{batch}_{window}.csv`
  - 离线模型、最新模型与生命周期模型的 R2 记录
- `/ossfs/workspace/vm_Q4/train_Q4/output/pred_model_{layer}_{batch}_{window}.csv`
  - wafer_id、真实值、离线/最新/生命周期预测值

调试缓存：
- `/ossfs/workspace/vm_Q4/train_Q4/data/data_{layer}.csv`

## 注意事项
- 数据库表结构需匹配 `DatabaseHandler` 预期
- 类别特征缺失样本会被直接剔除
- 多模型加权依赖 `getBestModel_multi_model` 的输出权重
- 贡献度窗口通过样本损失淘汰低贡献样本，可能影响窗口分布
