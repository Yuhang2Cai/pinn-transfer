# life.py README

## 简介
`life.py` 用于基于数据生命周期（贡献度淘汰策略）的在线增量学习。它维护两个数据窗口（时间窗口 + 贡献度窗口），通过计算样本预测误差衡量贡献度，淘汰低贡献样本，并定期训练更新模型。

## 适用场景
- 生产环境模型需长期在线更新
- 数据分布持续变化但不希望纯时间淘汰
- 希望优先保留“对模型最有价值”的样本

## 运行流程（概览）
1. 定时任务触发，拉取或加载增量数据
2. 更新数据窗口（时间窗口 + 贡献度窗口）
3. 训练生命周期模型并评估性能
4. 基于样本损失计算贡献度并淘汰低贡献样本
5. 输出指标与预测结果对比文件

## 依赖
Python 包：
- pandas, numpy, scikit-learn
- apscheduler
- pyyaml

项目内部模块：
- `utils.logging_setup`
- `database.base`
- `data_utils.*`

## 配置说明
配置文件由 `load_yaml` 读取（示例：`/ossfs/workspace/vm_Q4/config/G4B_TCP_01_DEP.yaml`），主要字段包括：
- `COMMON`: 模型参数、特征配置、滑窗大小等
- `DEV/PROD/TLF_TEST`: 数据库连接与定时任务间隔（`interval`）

常用配置项（`COMMON`）：
- `train_size`: 滑动窗口大小
- `buffer_threshold`: 触发训练的最小新增数据量
- `list_category`: 类别特征列表
- `model_param` / `model_param_online`: 模型超参
- `fix_feature_flag`: 是否固定特征维度
- `target`: 目标列索引或名称
- `model_version`: 当前模型版本号
- `pre_process`: 是否关联前站数据

## 使用方法
在项目根目录执行：
```bash
python life.py --TLF_TEST DEV
```
切换为生产环境：
```bash
python life.py --TLF_TEST PROD
```

## 关键类与函数

### DataMonitorAndTrainer
核心监控与训练类，负责调度、数据拉取、贡献度淘汰与模型更新。

初始化参数（核心）：
- `config`: 业务配置（来自 `COMMON`）
- `db_config`: 数据库连接配置
- `window_size`: 时间窗口大小
- `batch_size`: 触发训练的新增数据量阈值
- `interval`: 定时任务间隔（分钟）
- `target`, `k_fold`
- `list_category`, `layer_info`, `fix_feature_flag`
- `model_param`, `model_param_online`
- `last_check_time`: 增量拉取起点

核心方法（简述）：
- `fetch_new_data(...) -> DataFrame`
  - 从数据库拉取增量数据（支持前站数据关联）
- `update_data_window(new_data)`
  - 维护时间窗口（FIFO）与贡献度窗口
- `train_model()`
  - 训练生命周期模型并评估 R2
  - 基于样本损失淘汰低贡献样本
- `monitor_and_train(config)`
  - 定时任务入口：拉取 -> 更新窗口 -> 训练
- `fetch_and_save_data(config)` / `load_from_csv(config)`
  - 调试用数据缓存读写
- `shutdown()`
  - 关闭调度器

### split_dataset(old_data, new_data) -> (train_df, test_df)
合并新旧数据后按 8:2 随机划分训练/测试集。

## 输出与文件
运行过程中生成：
- `r2_life_{layer}_{batch}_{window}.csv`：离线模型 vs 生命周期模型的 R2 记录
- `pred_life_{layer}_{batch}_{window}.csv`：预测值对比（真值、离线、生命周期）

## 注意事项
- 数据库表结构需匹配 `DatabaseHandler` 的预期
- 贡献度淘汰基于样本预测误差（均方误差）
- 默认示例从缓存加载 CSV，可按需切换为在线拉取
