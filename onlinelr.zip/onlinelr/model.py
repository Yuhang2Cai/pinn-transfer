import argparse
import os
import traceback
from datetime import datetime, timedelta
import time
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score
import yaml
import logging
from apscheduler.schedulers.background import BackgroundScheduler
from typing import Tuple
from pathlib import Path
import sys

# 自定义模块导入
sys.path.append(str(Path(__file__).parent.parent))
from database.base import DatabaseHandler
from data_utils.load_config import load_yaml
from data_utils.data_loader import getDataOnline, getDataOnlinePreProcess
from data_utils.model_selection_mul import getBestModel_multi_model
from data_utils.model_selection import getBestModel, getBestModel_init
from data_utils.predict import model_predict
from data_utils.data_filter import align_old_model_with_feature
from utils.logging_setup import configure_logger

# 关闭 APScheduler 的 warning 日志
logging.getLogger("apscheduler.scheduler").setLevel(logging.ERROR)
logging.getLogger("apscheduler.executors.default").setLevel(logging.ERROR)


# 原数据划分：合并新旧数据后随机按 8:2 划分训练/测试
def split_dataset(old_data, new_data) -> Tuple[pd.DataFrame, pd.DataFrame]:

    """ 数据集划分策略，random 8:2 """
    data = pd.concat((old_data, new_data))
    train, test = train_test_split(data, test_size=0.2, random_state=42)

    return train, test



class DataMonitorAndTrainer:
    def __init__(self, config, db_config, window_size: int = 100, batch_size: int = 100, interval=1,
                 target=0,
                 k_fold=5,
                 model_param={},
                 model_param_online={},
                 list_category=[],
                 layer_info={},
                 fix_feature_flag=True,
                 last_check_time=datetime.now()):
        """
        :param db_config: 数据库连接参数
        :param window_size: 滑动窗口大小
        :param batch_size: 每次触发训练的更新数据量阈值
        :param interval: 定义查询间隔x分钟
        """
        # 记录不同漂移度量的历史值，便于后续输出与分析
        self.drift_history = {
            'wasserstein': [0],
            'ks': [0],
            'lsdd': [0],
            'iforest': [0],
            'timestamps': [0]
        }
        # 预处理后的参考集（例如缺失值处理或特征对齐后的历史数据）
        self.preprocessed_reference = None  # 专门存储预处理后的历史数据
        self.detection_count = 0
        self.fixed_reference = None  # 新增固定参考数据存储
        self.processed_current = None
        self.is_first_run = True  # 新增首次运行标记
        self.first_drift_flag = True
        self.first_scaler = True
        self.force_update_counter = 0
        self.fixed_ref = False
        self.force_update = False
        # self.drift_threshold = config['drift_threshold']
        self.offline_model_predict_r2 = []
        self.actual_model_predict_r2 = []
        self.r2_history_drift = []
        self.r2_history_life = []
        self.test_data_cleaned = None
        self.n_update = 0

        # 新增：模型相关参数初始化
        # 维护“最新/离线/生命周期多模型”的状态，用于不同路径的评估与更新
        self.life_model = None  # 存储当前使用的模型
        self.life_x_mean_std = None  # 存储标准化参数
        self.models = []  # 存储多个模型
        self.model_weights = []  # 存储模型权重

        self.offline_model = None
        self.offline_x_mean_std = None

        self.view_flage = False
        # self.enable_sample_weight = False  ###是否使用样本权重

        # 用于数值特征标准化（训练与预测保持一致）
        self.scaler = StandardScaler()

        self.window_size = window_size

        self.batch_size = batch_size
        # 训练数据滑动窗口（时间维度 FIFO）
        self.data_window = pd.DataFrame()  # 存储最新训练数据的滑动窗口
        # 2. 新增贡献度淘汰窗口（按损失淘汰）
        # 贡献度窗口：根据样本损失淘汰低贡献样本
        self.data_window_contribution = pd.DataFrame()  # 新：按损失淘汰最低贡献数据
        # 3. 新增损失存储列（用于贡献度窗口）
        self.loss_col = "sample_loss"  # 存储单个数据的模型损失
        self.new_data_length = 0  # 标记新到数据的量，作为训练开始的判断
        self.last_check_time = last_check_time  # 记录上次检查时间
        self.target = target
        self.k_fold = k_fold
        self.list_category = list_category
        self.layer_info = layer_info
        self.model_param = model_param
        self.model_param_online = model_param_online
        self.fix_feature = fix_feature_flag

        self.scheduler = BackgroundScheduler()

        # 示例模型
        # self.model = LinearRegression()
        self.model = None

        self.db_handler = DatabaseHandler(db_config=db_config)

        # 启动定时任务：周期性拉取数据并训练
        self.scheduler.add_job(
            self.monitor_and_train,
            'interval',
            minutes=interval,  # 每30秒检查一次
            next_run_time=datetime.now(),  # 立即开始
            # max_instances=28,
            end_date=datetime.now() + timedelta(hours=30),
            kwargs={'config': config}
        )
        self.scheduler.start()

        self.last_x_train = None
        self.last_y_train = None
        self.last_x_val = None
        self.last_y_val = None

        self.config = config
        self.history_predict_data = pd.DataFrame()  # 存储最新训练数据的滑动窗口

        self.online_wafer_ids = []  # 线上到来的wafer_id
        self.y_true = []  # wafer的真实量测值
        self.actual_model_predict_value = []  # 线上模型实际预测的量测值1.1
        self.drift_model_predict_value = []  # 1.2
        self.offline_model_predict_value = []  # 离线模型实际预测的量测值
        self.life_model_predict_value = []  # 1.3



    def fetch_new_data(self, ope_no, tool_type, recipe_short, product_id, fab_id, dcitem, met_no, train_size,
                       buffer_threshold, test_online, pre_process_info, version) -> pd.DataFrame:
        """返回自上次检查时间以来的新数据"""
        logger.info(f"拉取<{self.last_check_time}>以后更新的数据")
        # 1. 获取原始数据
        # 基于 last_check_time 拉取增量数据
        new_data = getDataOnline(
            db_handler=self.db_handler,
            ope_no=ope_no,
            tool_type=tool_type,
            recipe_short=recipe_short,
            product_id=product_id,
            fab_id=fab_id,
            dcitem=dcitem,
            met_no=met_no,
            train_size=train_size,
            buffer_threshold=buffer_threshold,
            test_online=test_online,
            version=version,
            update_time=self.last_check_time
        )
        self.db_handler.first_load_data = False
        print(f"数据版本号版本号:{version}")
        logger.info(f"成功拉取当站数据{len(new_data)} 条数据")
        # logger.info(f"成功拉取当站数据{len(new_data)} 条数据")
        if len(new_data) ==0:
            time.sleep(3600)

        # 2. 获取前站预处理数据
        # 可选：关联前站预处理数据（按 wafer_id 合并）
        if pre_process_info and len(new_data) > 0:
            pre_new_data = getDataOnlinePreProcess(
                db_handler=self.db_handler,
                ope_no=pre_process_info["OPE_NO"][0],
                tool_type=pre_process_info["TOOL_TYPE"][0],
                product_id=pre_process_info["PRODUCT"],
                fab_id=pre_process_info["FAB_ID"],
                dcitem=pre_process_info["DCITEM"][0],
                met_no=pre_process_info["MET_NO"][0],
                wafer_list=new_data["wafer_id"].tolist(),
                update_time=self.last_check_time
            )
            logger.info(f"成功拉取前站数据{len(pre_new_data)} 条数据")

            if len(pre_new_data) > 0:
                # 3. 合并数据并处理
                new_data = pd.merge(
                    new_data,
                    pre_new_data,
                    on='wafer_id',
                    how='left',
                    suffixes=("", "_pre")
                )

                # 移除合并产生的冗余列
                if "update_time_pre" in new_data.columns:
                    new_data = new_data.drop(columns=["update_time_pre"])

                # 检查合并后的数据完整性
                inner_join_data = pd.merge(
                    new_data, pre_new_data,
                    on='wafer_id', how='inner'
                )
                logger.info(f"当站与前站数据差距{len(new_data) - len(inner_join_data)} 条数据")

        # 4. 关键：类别特征空值处理与异常点剔除
        # 类别特征缺失时直接剔除，避免错误编码影响训练
        if hasattr(self, 'list_category') and self.list_category:
            # 计算原始数据量
            original_count = len(new_data)

            # 创建类别特征缺失标记
            for col in self.list_category:
                if col in new_data.columns:
                    # 标记空值点
                    new_data[f"{col}_is_missing"] = new_data[col].isna()

            # 确定需要检查的类别特征列（实际存在于数据中的）
            valid_cat_cols = [col for col in self.list_category if col in new_data.columns]

            if valid_cat_cols:
                # 创建综合缺失标记（任一类别特征缺失即为True）
                new_data['any_cat_missing'] = new_data[[f"{col}_is_missing" for col in valid_cat_cols]].any(axis=1)

                # 分离有效数据和缺失数据
                valid_data = new_data[~new_data['any_cat_missing']]
                missing_data = new_data[new_data['any_cat_missing']]

                # 记录剔除信息
                missing_count = len(missing_data)
                logger.warning(
                    f"剔除{missing_count}条含空类别特征的数据 "
                    f"(占比:{missing_count / max(1, original_count):.1%}) "
                    f"剩余数据量:{len(valid_data)}"
                )

                # 打印详细的缺失情况
                if not missing_data.empty:
                    # 汇总各特征的缺失情况
                    missing_stats = {}
                    for col in valid_cat_cols:
                        missing_stats[col] = missing_data[col].isna().sum()

                    logger.info(f"各特征缺失统计: {missing_stats}")

                    # 记录被剔除的wafer_id（前10条）
                    sample_ids = missing_data['wafer_id'].head(10).tolist()
                    logger.debug(f"部分被剔除的wafer_id: {sample_ids}")

                # 移除临时列并返回有效数据
                new_data = valid_data.drop(
                    columns=[f"{col}_is_missing" for col in valid_cat_cols] + ['any_cat_missing'],
                    errors='ignore'
                )


            else:
                logger.warning("配置的类别特征在当前数据中均不存在")


        else:
            logger.error("未定义类别特征列表list_category，跳过空值检查")

        # 5. 最终数据量检查
        # 数据量不足时仅做标记（不触发训练）
        if len(new_data) < self.batch_size:
            self.view_flage = True
            logger.info(f"新数据量不足阈值({self.batch_size})，当前:{len(new_data)}")

        return new_data
        
    def update_data_window(self, new_data: pd.DataFrame):

        """
        保留原时间淘汰窗口，新增贡献度淘汰窗口维护
        1. self.data_window_time：原逻辑（保留最新window_size条）
        2. self.data_window_contribution：新逻辑（按损失淘汰最低贡献n条）
        """
        # n 对应当前新增样本数，用于后续淘汰逻辑
        n = len(new_data)  # 滑动n个数据，需淘汰n个

        # ---------------------- 1. 维护原时间淘汰窗口（完全保留原有逻辑）----------------------
        self.data_window = pd.concat([self.data_window, new_data], ignore_index=True)
        if len(self.data_window) > self.window_size:
            self.data_window = self.data_window.iloc[-self.window_size:]  # 保留最新的
        logger.info(f"原时间窗口更新：当前大小{len(self.data_window)}")

        # ---------------------- 2. 维护新贡献度淘汰窗口（新增逻辑）----------------------
        # 2.1 首次运行时直接累积；后续则拼接“淘汰后的历史”与新数据
        if self.is_first_run:
            # 如果是首次运行，直接将新数据添加到贡献度窗口中
            self.data_window_contribution = pd.concat(
                [self.data_window_contribution, new_data],
                ignore_index=True
            )
            logger.info(f"首次运行，直接添加新数据 | 当前窗口大小: {len(self.data_window_contribution)}")
            return
        self.data_window_contribution = pd.concat(
            [self.test_data_cleaned, new_data],
            ignore_index=True
        )

        # 移除时间戳型列（避免被作为数值特征进入训练）
        timestamp_columns = []
        for col in self.data_window.columns:
            # 检查是否为时间戳类型且不是类别特征
            if (pd.api.types.is_datetime64_any_dtype(self.data_window[col]) and 
            col not in self.list_category and
            col != 'update_time'): 
                timestamp_columns.append(col)
        
        if timestamp_columns:
            logger.info(f"排除时间戳类型列: {timestamp_columns}")
            self.data_window = self.data_window.drop(columns=timestamp_columns, errors='ignore')
        else:
             logger.info("数据窗口无时间戳列")

        # 贡献度窗口同样去除时间戳列，保证特征对齐
        timestamp_columns_contribution = []
        for col in self.data_window_contribution.columns:
            # 检查是否为时间戳类型且不是类别特征
            if (pd.api.types.is_datetime64_any_dtype(self.data_window_contribution[col]) and 
                col not in self.list_category and
                col != 'update_time'):
                timestamp_columns_contribution.append(col)
        
        if timestamp_columns_contribution:
            logger.info(f"排除时间戳类型列: {timestamp_columns_contribution}")
            self.data_window_contribution = self.data_window_contribution.drop(columns=timestamp_columns_contribution, errors='ignore')
        else:
             logger.info("贡献度窗口无时间戳列")


        logger.info(f"最终窗口大小: {len(self.data_window_contribution)}")

    def train_model(self):
        # 首次运行：训练离线基线模型，作为后续对照
        if  self.is_first_run:
            train_set, test_set = split_dataset(self.data_window[:-self.batch_size],
                                                self.data_window[-self.batch_size:])
        # 训练初始模型
            model_off,x_mean_std_offline = getBestModel_init(train_set,
                                                                                     test_set,
                                                                                     target=self.target,
                                                                                     k_fold=self.k_fold,
                                                                                     list_category=self.list_category,
                                                                                     # old_model=self.newest_model,
                                                                                     fix_feature=self.fix_feature,
                                                                                     model_param=self.model_param_online)
            self.offline_model = model_off
            self.offline_x_mean_std = x_mean_std_offline

        # 特征对齐后的new_data数据
        else:

            test_data = align_old_model_with_feature(self.offline_model, self.data_window[-self.batch_size:].copy(),
                                                     self.offline_x_mean_std)

            # 使用离线模型评估当前批次，记录基线效果
            metrics_old, old_wafer_id, old_real, old_pre, test_feat, test_y_bias = model_predict(model=self.offline_model,
                                                                                                 data=test_data,
                                                                                                 standardization=self.offline_x_mean_std,
                                                                                                 list_category=self.list_category,
                                                                                                 target=self.target)
            # 保存离线模型预测信息
            self.offline_model_predict_value.extend(old_pre)
            self.y_true.extend(old_real)
            self.online_wafer_ids.extend(old_wafer_id)

            self.offline_model_predict_r2.append(metrics_old['r2'])
            logger.info(f"当前数据库中的离线模型预测R2：{metrics_old['r2']}")

            logger.info("使用最新模型预测新到的片")
        ######################################################## 最新的在线模型###################################
        print("#######在线模型########")
        if self.is_first_run:
            self.newest_model = self.offline_model
            self.x_mean_std_newest = self.offline_x_mean_std
            train_set, test_set = split_dataset(self.data_window[:-self.batch_size],
                                                self.data_window[-self.batch_size:])

        else:

            test_data = align_old_model_with_feature(self.newest_model, self.data_window[-self.batch_size:].copy(),
                                                         self.x_mean_std_newest)
            logger.info(f"测试数据量为：{len(test_data)}")

            metrics_newest, newest_wafer_id, newest_real, newest_pre, test_feat, test_y_bias = model_predict(
                model=self.newest_model,
                data=test_data,
                standardization=self.x_mean_std_newest,
                list_category=self.list_category,
                target=self.target)




            self.actual_model_predict_value.extend(newest_pre)
            self.actual_model_predict_r2.append(metrics_newest['r2'])
            logger.info(f"当前数据库中的最新模型预测R2：{metrics_newest['r2']}")

        train_set, test_set = split_dataset(self.data_window[:-self.batch_size], self.data_window[-self.batch_size:])

        # train_set, test_set = self.train_set.copy(), self.test_set.copy()

        # 训练“最新模型”，用于线上预测与更新
        model, x_mean_std, confidence_param, update_flag, metrics_new = getBestModel(train_set,
                                                                                     test_set,
                                                                                     target=self.target,
                                                                                     k_fold=self.k_fold,
                                                                                     list_category=self.list_category,
                                                                                     old_model=self.newest_model,
                                                                                     fix_feature=self.fix_feature,
                                                                                     model_param=self.model_param_online)

        self.newest_model = model
        self.x_mean_std_newest = x_mean_std

        ##############################################数据生命周期######################################
        # 仅第一次运行时从数据库读取模型
        print("#######多模型########")
        if self.is_first_run:
            # 初始化模型列表和权重（使用单个模型）
            self.models = [self.newest_model]
            self.model_weights = [1.0]
            self.life_model = self.newest_model
            self.life_x_mean_std = self.x_mean_std_newest

            # 第一次运行时跳过预测，直接进行模型训练

        else:
            test_data = align_old_model_with_feature(self.life_model, self.data_window[-self.batch_size:].copy(),
                                                     self.life_x_mean_std)

            # 使用多模型加权进行预测，缓解单模型漂移风险
            weighted_predictions = []
            life_real = None

            for model, weight in zip(self.models, self.model_weights):
                try:
                    # 为每个模型重新对齐特征并处理NaN值
                    aligned_test_data = align_old_model_with_feature(model, test_data.copy(), self.life_x_mean_std)

                    # 处理分类特征中的NaN值
                    for col in self.list_category:
                        if col in aligned_test_data.columns:
                            aligned_test_data[col] = aligned_test_data[col].fillna("NaN").astype(str)



                    metrics, wafer_id, real, pred, feat, y_bias = model_predict(
                        model=model,
                        data=aligned_test_data,
                        standardization=self.life_x_mean_std,
                        list_category=self.list_category,
                        target=self.target
                    )
                    weighted_predictions.append(np.array(pred) * weight)

                    # 从model_predict的返回值中获取真实值（只需要获取一次）
                    if life_real is None:
                        life_real = real
                        # self.y_true.extend(real)


                except Exception as e:
                    logger.error(f"模型预测失败: {str(e)}")
                    # 如果某个模型预测失败，使用0权重继续
                    weighted_predictions.append(np.zeros(len(test_data)))
                    continue

            # 计算加权平均预测并记录 R2
            if weighted_predictions:
                final_predictions = np.sum(weighted_predictions, axis=0)

                # 计算加权预测的R2
                if life_real is not None and len(life_real) == len(final_predictions):
                    weighted_r2 = r2_score(life_real, final_predictions)
                    self.life_model_predict_value.extend(final_predictions)
                    self.r2_history_life.append(weighted_r2)
                    logger.info(f"当前加权模型预测R2：{weighted_r2}")
                else:
                    logger.warning("真实值和预测值长度不匹配，无法计算R2")
                    # 使用第一个成功模型的指标
                    if 'metrics' in locals():
                        self.r2_history_life.append(metrics['r2'])
                        logger.info(f"使用单个模型R2：{metrics['r2']}")
            else:
                logger.warning("所有模型预测都失败")

        train_set, test_set = split_dataset(self.data_window[:-self.batch_size],
                                            self.data_window[-self.batch_size:])

        # 使用第一个模型作为old_model传入getBestModel
        models, model_weights, x_mean_std, confidence_param, update_flag, metrics_new = getBestModel_multi_model(
            train_set, test_set, target=self.target, k_fold=self.k_fold,
            list_category=self.list_category, old_model=self.models[0],  # 使用第一个模型作为old_model
            fix_feature=self.fix_feature, model_param=self.model_param
        )

        # 存储训练后的模型和参数到类对象中
        self.models = models
        self.model_weights = model_weights
        self.life_model = models[0]  # 使用第一个模型作为主要模型
        self.life_x_mean_std = x_mean_std
        logger.info(f"模型权重{model_weights}")

        # 使用权重最大的模型计算损失
        best_model_idx = np.argmax(model_weights)
        best_model = models[best_model_idx]

        # 使用最佳权重模型计算样本损失，淘汰低贡献样本
        test_data_update = align_old_model_with_feature(best_model, self.data_window.copy(), x_mean_std)

        for col in self.list_category:
            if col in test_data_update.columns:
                test_data_update[col] = test_data_update[col].fillna("NaN").astype(str)

        metrics_best, best_wafer_id, best_real, best_pre, best_feat, best_y_bias = model_predict(
            model=best_model,
            data=test_data_update,
            standardization=x_mean_std,
            list_category=self.list_category,
            target=self.target)

        # 计算每个样本的损失（使用均方误差）
        losses = np.square(np.array(best_real) - np.array(best_pre))
        lowest_loss_indices = np.argsort(losses)[:self.batch_size]
        self.test_data_cleaned = test_data_update.drop(test_data_update.index[lowest_loss_indices])

        logger.info(f"已剔除{len(lowest_loss_indices)}个损失最低的样本，剩余{len(self.test_data_cleaned)}个样本")

        output_dir = "/ossfs/workspace/vm_Q4/train_Q4/output"
        os.makedirs(output_dir, exist_ok=True)
        result_df = pd.DataFrame()
        result_df['offline_model_predict_r2'] = self.offline_model_predict_r2
        result_df['actual_model_predict_r2'] = self.actual_model_predict_r2
        result_df['r2_history_life'] = self.r2_history_life
        result_df.to_csv(f"{output_dir}/r2_model_{self.config['layer_name']}_{self.batch_size}_{self.window_size}.csv",
                         index=None)

        result_df = pd.DataFrame()
        result_df['online_wafer_ids'] = self.online_wafer_ids
        result_df['y_true'] = self.y_true
        result_df['offline_model_predict_value'] = self.offline_model_predict_value
        result_df['actual_model_predict_value'] = self.actual_model_predict_value
        result_df['life_model_predict_value'] = self.life_model_predict_value
        result_df.to_csv(f"{output_dir}/pred_model_{self.config['layer_name']}_{self.batch_size}_{self.window_size}.csv",
                         index=None)

        logger.info(f"离线r2记录{len(self.offline_model_predict_r2)}{self.offline_model_predict_r2}")
        logger.info(f"在线r2记录{len(self.actual_model_predict_r2)}{self.actual_model_predict_r2}")
        logger.info(f"生命周期更新r2记录{len(self.r2_history_life)}{self.r2_history_life}")
        logger.info(f"正在跑的实验：{config['layer_name'],config['train_size'],config['buffer_threshold']},脚本：mian_off_on_model.py")

        logger.info("一轮处理结束")
        self.is_first_run = False  # 标记首次运行已完成

    def fetch_and_save_data(self, config):
        """
        获取数据并保存到CSV文件
        """
        # 用于调试/离线测试：先拉取后缓存
        # 生成保存路径
        filename = f"/ossfs/workspace/vm_Q4/train_Q4/data/data_{config['layer_name']}.csv"
        save_path = os.path.join("./data_cache", filename)
        
        # 创建目录（如果不存在）
        os.makedirs("./data_cache", exist_ok=True)
        
        # 获取数据
        print("拉取新数据...")
        new_data = self.fetch_new_data(
            config["siteID"],
            config["tool_type"],
            config["recipe_short"],
            config["product_id"],
            config["fab_id"],
            config["metParamID"],
            config["metID"],
            10000,
            config["buffer_threshold"],
            config["test_online"],
            config["pre_process"],
            config["model_version"]
        )
        
        if not new_data.empty:
            # 保存到CSV
            new_data.to_csv(save_path, index=False, encoding='utf-8-sig')
            print(f"数据已保存到: {save_path}")
            print(f"数据形状: {new_data.shape}")
            print(f"数据时间范围: {new_data['update_time'].min()} - {new_data['update_time'].max()}")
        
        else:
            print("没有数据")
        
        return new_data

    def load_from_csv(self, config):
        """
        从CSV文件加载数据
        """
        # 优先从缓存读取，避免反复请求数据库
        # 生成文件路径
        filename = f"/ossfs/workspace/vm_Q4/train_Q4/data/data_{config['layer_name']}.csv"
        filepath = os.path.join("./data_cache", filename)
        
        if not os.path.exists(filepath):
            print(f"缓存文件不存在: {filepath}")
            return pd.DataFrame()
        
        try:
            data = pd.read_csv(filepath)
            # 确保update_time是datetime类型
            if 'update_time' in data.columns:
                data['update_time'] = pd.to_datetime(data['update_time'])
            print(f"从缓存加载数据成功: {filepath}")
            print(f"数据形状: {data.shape}")
            if not data.empty:
                print(f"数据时间范围: {data['update_time'].min()} - {data['update_time'].max()}")
            return data
        except Exception as e:
            logger.error(f"加载缓存文件失败: {str(e)}")
            return pd.DataFrame()

    def monitor_and_train(self, config):
        """
        定时执行的主逻辑：
        1. 检查新数据
        2. 如果有足够新数据，更新窗口并训练模型

        """
        if self.is_first_run:
            print("首次拉数据")
            # 首次启动：从缓存读取历史数据并初始化窗口
            # self.new_data = self.fetch_and_save_data(config)
            self.new_data = self.load_from_csv(config)
            if not self.new_data.empty:
                self.new_data_length = self.new_data.shape[0]
                self.last_check_time = self.new_data["update_time"].max()
                old_check_time = self.new_data["update_time"].min()
                print(f"数据时间{old_check_time}-{self.last_check_time}")
                # 将 self.new_data按照["update_time"]排序
                self.new_data = self.new_data.sort_values(by=["update_time"])
                #new_data为self.new_data中索引最小的self.window_size条数据
                new_data =self.new_data.iloc[:self.window_size]
                self.new_data = self.new_data.iloc[self.window_size:]
                logger.info(f"数据时间{new_data['update_time'].max()}-{new_data['update_time'].min()}")


        else:
            # 后续按 batch_size 分批处理
            if len(self.new_data) > self.batch_size:
                
                new_data = self.new_data.iloc[:self.batch_size]
                self.new_data = self.new_data.iloc[self.batch_size:]
                logger.info(f"数据时间{new_data['update_time'].max()}-{new_data['update_time'].min()}")
                print(f"剩下的数据量{len(self.new_data)}")

            else:
                print("数据量不足")
                time.sleep(100000)
                

        try:
            # 更新窗口后触发训练
            self.update_data_window(new_data)

            print(f"抓取{self.new_data_length}条新数据")
                
            self.train_model()
            


        except Exception as e:
            logger.error(traceback.format_exc())
            logger.error(f"Error in monitoring job: {str(e)}")

    def shutdown(self):
        """关闭调度器"""
        self.scheduler.shutdown()

    
# 使用示例
if __name__ == "__main__":
    # import signal
    import time
    import os, random, numpy as np
    SEED = 42
    os.environ["PYTHONHASHSEED"] = str(SEED)
    random.seed(SEED)
    np.random.seed(SEED)

    # 加载配置
    # 创建 ArgumentParser 对象
    parser = argparse.ArgumentParser(description='开发生产环境切换')
    # 添加参数
    # TODO 记得切换测试环境
    parser.add_argument('--TLF_TEST', type=str, help='<DEV>/<PROD>', default="TLF_TEST")

    # 解析参数
    args = parser.parse_args()
    # 加载配置文件
    # config = load_yaml(r'Q:\vscodefile\vm\vm_active_trim2_04\config\G4_TCP_01_DEP.yaml')
    # config = load_yaml(r'Q:\vscodefile\vm\vm_active_trim2_04\config\G4_TCP_01_DEP_THK.yaml')
    # config = load_yaml(r'Q:\vscodefile\vm\vm_active_trim2_04\config\G4B_PCP_10_DEP.yaml')
    # config = load_yaml(r'/ossfs/workspace/vm_Q4/config/G4B_TCP_01_DEP.yaml')
    # config = load_yaml(r'/ossfs/workspace/vm_Q4/config/G4B_TCP_01_DEP_THK.yaml')
    config = load_yaml(r'/ossfs/workspace/vm_Q4/config/G4B_PCU_10_DEP.yaml')

    args.env = args.TLF_TEST.upper()
    # 开发环境
    # common_args = args['COMMON']
    env_args = config[args.env]
    db_config = env_args["db_info"]
    config = config["COMMON"]
    # 数据库连接

    # 生产环境
    # 类别属性
    list_category = config['list_category']
    model_config = config['model_param']
    # 日志名、路径
    # logger_name = config['logger_name']
    logger_path = config['logger_path']
    # 新数据累积到一定数量触发更新
    buffer_threshold = config['buffer_threshold']
    train_size = config['train_size']

    """layer 信息"""
    ope_no = config['siteID']
    tool_type = config['tool_type']
    recipe_short = config['recipe_short']
    product_id = config["product_id"]
    fab_id = config["fab_id"]
    dcitem = config['metParamID']
    met_no = config['metID']
    k_fold = config['k_fold']
    target = config['target']
    layer_name = config['layer_name']
    model_param = config['model_param']
    model_param_online = config['model_param_online']
    fix_feature_flag = config['fix_feature_flag']
    interval = env_args['interval']
    pre_process = config['pre_process']
    layer_info = {"ope_no": ope_no, "product_id": product_id, "fab_id": fab_id,
                  "dcitem": dcitem, "tool_type": tool_type,
                  "recipe_short": recipe_short,
                  "layer": layer_name, "version": config["model_version"]}
    # from pathlib import Path
    # # logs 文件如不存在，则创建
    # logger_p = Path(logger_path)
    # logger_p.parent.mkdir(parents=True, exist_ok=True)

    # 初始化日志与监控器，开始定时训练
    logger = configure_logger(log_file=f'{logger_path}')
    monitor = DataMonitorAndTrainer(config, db_config=db_config, window_size=train_size, batch_size=buffer_threshold,
                                    interval=interval,
                                    k_fold=k_fold,
                                    target=target,
                                    list_category=list_category,
                                    layer_info=layer_info,
                                    fix_feature_flag=fix_feature_flag,
                                    model_param=model_param,
                                    model_param_online=model_param_online,
                                    last_check_time=datetime(2024, 1, 1, 0, 0, 0))

    # todo： 固定向前查固定日期数据
    # 25

    # # 处理程序退出
    # def signal_handler(sig, frame):
    #     monitor.shutdown()
    #     exit(0)
    #
    #
    # signal.signal(signal.SIGINT, signal_handler)

    logger.info("Monitoring started. Press Ctrl+C to stop.")
    try:
        # 主线程保持运行
        while True:
            time.sleep(1)
    except (KeyboardInterrupt, SystemExit):
        monitor.shutdown()
