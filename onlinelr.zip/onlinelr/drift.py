"""
drift.py - 数据漂移检测与在线模型增量训练模块

主要功能：
1. 定时从数据库拉取新数据
2. 使用多种算法检测数据分布漂移（KS检验、Wasserstein距离、LSDD、孤立森林）
3. 根据漂移检测结果自动决定是否重新训练模型
4. 将更新后的模型序列化并存储到数据库

核心类：DataMonitorAndTrainer
"""

import argparse
import os
import pdb
import pickle
import traceback
import logging
import sys
import math
import time
import queue
import warnings
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Optional, Tuple

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib
import seaborn as sns
import yaml

from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest
from sklearn.metrics import r2_score, mean_absolute_percentage_error, accuracy_score

from scipy.stats import wasserstein_distance
from alibi_detect.cd import LSDDDrift, KSDrift

from apscheduler.schedulers.background import BackgroundScheduler

import catboost

# 项目内部模块
sys.path.append(str(Path(__file__).parent.parent))
sys.path.append('.')

from utils.logging_setup import configure_logger
from database.base import DatabaseHandler
from data_utils.load_config import load_yaml
from data_utils.data_loader import getDataOnline, getDataOnlinePreProcess
from data_utils.model_selection import getBestModel
from data_utils.predict import model_predict
from data_utils.data_filter import align_old_model_with_feature
from data_utils.gpr_model import gpr_get_confidence

# 关闭 APScheduler 的 warning 日志
logging.getLogger("apscheduler.scheduler").setLevel(logging.ERROR)
logging.getLogger("apscheduler.executors.default").setLevel(logging.ERROR)
warnings.filterwarnings(action='ignore', category=FutureWarning)

# Matplotlib中文显示配置
mpl.rcParams['font.family'] = 'SimHei'
mpl.rcParams['axes.unicode_minus'] = False
matplotlib.use('Agg')  # 非交互式后端，避免服务器环境报错


def split_dataset(old_data: pd.DataFrame, new_data: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    数据集划分策略函数
    
    当前策略：随机 8:2 划分
    其他可选策略（已注释）：按时间顺序划分、新旧数据混合划分等
    """
    # 策略1（已注释）：新数据50% + 旧数据10%作为测试集
    # train_old, test_old = train_test_split(old_data, test_size=0.1, random_state=42)
    # train_new, test_new = train_test_split(new_data, test_size=0.5, random_state=42)
    # train = pd.concat((train_old, train_new))
    # test = pd.concat((test_old, test_new))
    
    # 策略2（已注释）：按时间顺序划分
    # data = pd.concat((old_data, new_data))
    # data = data.sort_values("update_time")
    # train = data.iloc[: int(0.9 * data.shape[0]), :]
    # test = data.iloc[int(0.9 * data.shape[0]):, :]
    
    # 策略3（当前启用）：随机 8:2 划分
    data = pd.concat((old_data, new_data))
    train, test = train_test_split(data, test_size=0.2, random_state=42)
    
    return train, test


class DataMonitorAndTrainer:
    """
    数据监控与模型训练器
    
    负责协调数据获取、漂移检测和模型训练的全流程。
    使用APScheduler在后台运行定时任务，周期性执行监控和训练流程。
    
    Args:
        config: 系统配置字典
        db_config: 数据库连接配置
        window_size: 滑动窗口大小（保留的历史数据条数）
        batch_size: 触发训练的新数据量阈值
        interval: 定时任务执行间隔（分钟）
        target: 目标变量索引或列名
        k_fold: 交叉验证折数
        model_param: 模型超参数
        list_category: 类别型特征列表（漂移检测时会被排除）
        layer_info: 层级信息（工序、产品等标识）
        fix_feature_flag: 是否固定特征集
        last_check_time: 上次检查数据的时间戳
    """
    
    def __init__(self, config, db_config, window_size: int = 100, batch_size: int = 30, interval = 1,
                 target=0,
                 k_fold=5,
                 model_param={},
                 list_category=[],
                 layer_info={},
                 fix_feature_flag=True,
                 last_check_time=datetime.now()):
        
        # 漂移检测相关
        self.drift_history = {
            'wasserstein': [0],
            'ks': [0],
            'lsdd': [0],
            'iforest': [0],
            'timestamps': [0]
        }
        self.preprocessed_reference = None  # 预处理后的参考数据（漂移检测基准）
        self.detection_count = 0
        self.fixed_reference = None  # 固定参考数据（首次运行时设置）
        self.processed_current = None
        self.is_first_run = True
        self.first_drift_flag = True
        self.first_scaler = True
        self.force_update_counter = 0
        self.fixed_ref = False
        self.force_update = False
        self.drift_threshold = config['drift_threshold']
        
        # 模型预测R²历史记录
        self.offline_model_predict_r2 = []  # 离线模型（最早的模型）
        self.actual_model_predict_r2 = []   # 在线模型（最新的模型）
        self.r2_history_drift = []          # 漂移检测专用模型
        
        self.view_flage = False
        self.enable_sample_weight = False
        self.scaler = StandardScaler()

        # 滑动窗口相关
        self.window_size = window_size
        self.batch_size = batch_size
        self.data_window = pd.DataFrame()
        self.new_data_length = 0
        self.last_check_time = last_check_time
        
        # 模型训练相关
        self.target = target
        self.k_fold = k_fold
        self.list_category = list_category
        self.layer_info = layer_info
        self.model_param = model_param
        self.fix_feature = fix_feature_flag

        self.scheduler = BackgroundScheduler()
        self.model = None
        self.db_handler = DatabaseHandler(db_config=db_config)

        # 启动定时任务：每interval分钟执行一次，运行5小时后自动停止
        self.scheduler.add_job(
            self.monitor_and_train,
            'interval',
            minutes=interval,
            next_run_time=datetime.now(),
            end_date=datetime.now() + timedelta(hours=5),
            kwargs={'config': config}
        )
        self.scheduler.start()

        # 训练数据缓存
        self.last_x_train = None
        self.last_y_train = None
        self.last_x_val = None
        self.last_y_val = None

        self.config = config
        self.history_predict_data = pd.DataFrame()

        # 预测结果存储
        self.online_wafer_ids = []
        self.y_true = []
        self.actual_model_predict_value = []
        self.drift_model_predict_value = []
        self.offline_model_predict_value = []

    def fetch_new_data(self, ope_no, tool_type, recipe_short, product_id, fab_id, dcitem, met_no, train_size,
                       buffer_threshold, test_online, pre_process_info, version) -> pd.DataFrame:
        """
        从数据库获取自上次检查时间以来的新数据
        
        支持前站数据预处理：如果配置了pre_process_info，会通过wafer_id关联前站数据
        """
        logger.info(f"拉取<{self.last_check_time}>以后更新的数据")
        
        new_data = getDataOnline(
            db_handler=self.db_handler,
            ope_no=ope_no,
            tool_type=tool_type,
            recipe_short=recipe_short,
            product_id=product_id,
            fab_id=fab_id,
            dcitem=dcitem,
            met_no=met_no,
            train_size=train_size,
            buffer_threshold=buffer_threshold,
            test_online=test_online,
            version=version,
            update_time=self.last_check_time
        )
        self.db_handler.first_load_data = False
        
        logger.info(f"成功拉取当站数据{len(new_data)} 条数据")
        
        if len(new_data) < self.batch_size:
            self.view_flage = True
            
        # 前站数据预处理：通过wafer_id关联前站数据
        if pre_process_info and len(new_data != 0):
            pre_new_data = getDataOnlinePreProcess(
                db_handler=self.db_handler,
                ope_no=pre_process["OPE_NO"][0],
                tool_type=pre_process["TOOL_TYPE"][0],
                product_id=pre_process["PRODUCT"],
                fab_id=pre_process["FAB_ID"],
                dcitem=pre_process["DCITEM"][0],
                met_no=pre_process["MET_NO"][0],
                wafer_list=new_data["wafer_id"].tolist(),
                update_time=self.last_check_time
            )
            
            logger.info(f"成功拉取前站数据{len(pre_new_data)} 条数据")
            
            if len(pre_new_data != 0):
                new_data = pd.merge(new_data, pre_new_data, on='wafer_id', how='left', suffixes=("", "_pre"))
                inner_join_data = pd.merge(new_data, pre_new_data, on='wafer_id', how='inner')
                new_data = new_data.drop(columns=["update_time_pre"])
                logger.info(f"当站与前站数据差距{len(new_data) - len(inner_join_data)} 条数据")
                
        return new_data

    def update_data_window(self, new_data: pd.DataFrame):
        """更新滑动窗口数据，保持最新的window_size条记录（FIFO策略）"""
        self.data_window = pd.concat([self.data_window, new_data], ignore_index=True)

        if len(self.data_window) > self.window_size:
            self.data_window = self.data_window.iloc[-self.window_size:]

        logger.info(f"Window updated. Current size: {len(self.data_window)}")

    # ==================== 漂移检测模块 ====================
    
    def normalize(self, data, reset):
        """
        数据标准化（Z-score）
        reset=True时重新fit，否则使用已有参数transform
        """
        if reset or self.first_scaler:
            self.first_scaler = False
            self.scaler = StandardScaler()
            return self.scaler.fit_transform(data)
        else:
            return self.scaler.transform(data)

    def _handle_missing_values(self, df, data_type):
        """
        缺失值处理：
        - 缺失比例 > 20%：直接剔除该列
        - 缺失比例 <= 20%：用该列中位数填充
        """
        missing_ratios = df.isnull().mean()
        processed_df = df.copy()
        dropped_cols = []
        
        print("运行填充############")
        logging.info(f"[{data_type}] 处理前数据形状: {df.shape}, 总缺失值: {df.isnull().sum().sum()}")
        print(f"[{data_type}] 处理前数据形状: {df.shape}, 总缺失值: {df.isnull().sum().sum()}")
        
        for col in df.columns:
            ratio = missing_ratios[col]
            if ratio == 0:
                continue
            if ratio > 0.2:
                dropped_cols.append(col)
                continue
            fill_value = df[col].median()
            processed_df[col].fillna(fill_value, inplace=True)
            logging.info(f"{data_type}特征'{col}':{ratio:.1%}缺失→填充自身中位数{fill_value:.3f}")

        if dropped_cols:
            processed_df = processed_df.drop(columns=dropped_cols)

        logging.info(f"[{data_type}] 处理后数据形状: {processed_df.shape}, 剩余特征: {len(processed_df.columns)}")
        print(f"[{data_type}] 处理后数据形状: {processed_df.shape}, 剩余特征: {len(processed_df.columns)}")

        return processed_df

    def _preprocess_data(self, df, feature_names_, data_type):
        """通用预处理：筛选有效特征 → 数值转换 → 缺失值处理"""
        valid_features = [f for f in feature_names_ if f not in self.list_category and f in df.columns]
        
        if not valid_features:
            logging.warning(f"{data_type}预处理失败: 无有效特征")
            return None

        data_subset = df[valid_features].copy()
        for col in valid_features:
            data_subset[col] = pd.to_numeric(data_subset[col], errors='coerce')

        processed_data = self._handle_missing_values(data_subset, data_type)
        return processed_data if not processed_data.empty else None

    def _prepare_for_drift_detection(self, ref_df, current_df):
        """准备漂移检测数据：特征对齐 → 数值转换 → 标准化"""
        common_cols = list(set(ref_df.columns) & set(current_df.columns))
        if not common_cols:
            logging.warning("漂移检测失败: 无共同特征")
            return None, None, None

        ref_aligned = ref_df[common_cols]
        current_aligned = current_df[common_cols]

        try:
            ref_final = ref_aligned.astype(float)
            current_final = current_aligned.astype(float)

            ref_scaled = self.normalize(ref_final, self.force_update)
            current_scaled = self.normalize(current_final, reset=False)

            ref_scaled = np.atleast_2d(ref_scaled)
            current_scaled = np.atleast_2d(current_scaled)

            logging.info(f"漂移检测数据准备完成 - 参考{ref_scaled.shape}, 当前{current_scaled.shape}")
            return ref_scaled, current_scaled, common_cols
        except Exception as e:
            logging.error(f"数据标准化失败: {str(e)}")
            return None, None, None

    def calculate_feature_drift(self, current_features, feature_names_, use_fixed_reference):
        """
        核心漂移检测函数
        
        处理三种场景：
        1. 当前数据为空 → 跳过
        2. 首次运行（无历史数据）→ 初始化参考数据
        3. 正常检测 → 执行漂移算法并返回结果
        
        返回值包含：wasserstein, ks, lsdd, iforest得分，以及status状态
        status: 'drift'(漂移) / 'moderate'(中等) / 'normal'(正常)
        """
        result = {
            'wasserstein': 0, 'ks': 0, 'lsdd': 0, 'iforest': 0,
            'is_drift': False, 'status': 'no_data'
        }

        if current_features is None or current_features.empty:
            logging.warning("当前数据为空，跳过处理")
            return result

        # 首次运行：初始化参考数据
        if self.is_first_run:
            logging.info("历史数据为空，仅预处理当前数据")
            self.processed_current = self._preprocess_data(current_features, feature_names_, "当前数据")

            if self.processed_current is not None:
                self.preprocessed_reference = self.processed_current
                self.fixed_reference = self.processed_current.copy()
                result['status'] = 'initialized'
                logging.info("历史数据已初始化")
            else:
                result['status'] = 'preprocess_failed'
            return result

        # 正常漂移检测流程
        logging.info("开始漂移检测流程")

        # 选择参考数据源
        if use_fixed_reference and self.fixed_reference is not None:
            processed_ref = self.fixed_reference
        else:
            processed_ref = self.preprocessed_reference

        if processed_ref is None:
            result['status'] = 'preprocess_failed'
            return result

        self.processed_current = self._preprocess_data(current_features, feature_names_, "当前数据")
        if self.processed_current is None:
            result['status'] = 'preprocess_failed'
            return result

        ref_matrix, current_matrix, valid_features = self._prepare_for_drift_detection(
            processed_ref, self.processed_current
        )
        if ref_matrix is None:
            return result

        # 执行漂移检测（默认使用KS检验，其他方法可按需启用）
        # result['wasserstein'] = self._calculate_wasserstein(ref_matrix, current_matrix, valid_features)
        result['ks'] = self._calculate_ks_drift(ref_matrix, current_matrix)
        # result['lsdd'] = self._calculate_lsdd_drift(ref_matrix, current_matrix)
        # result['iforest'] = self._calculate_iforest_drift(ref_matrix, current_matrix)

        # 综合评估
        avg_drift = result['ks']
        result['status'] = 'drift' if avg_drift > self.drift_threshold else \
            'moderate' if avg_drift > 0.1 else 'normal'

        self._update_drift_history(result)
        logging.info(f"漂移检测完成: 状态={result['status']}")

        return result

    def _calculate_wasserstein(self, ref_data, current_data, valid_features):
        """Wasserstein距离（推土机距离）：计算分布之间的最优传输距离"""
        try:
            distances = []
            for i in range(ref_data.shape[1]):
                try:
                    dist = wasserstein_distance(ref_data[:, i], current_data[:, i])
                    if not math.isnan(dist):
                        distances.append(dist)
                except:
                    continue
            avg_distance = np.mean(distances) if distances else 0
            return self._normalize_distance(avg_distance, 'wasserstein')
        except:
            logging.error("Wasserstein计算失败")
            return 0

    def _calculate_ks_drift(self, ref_data, current_data):
        """KS检验：比较两个样本的累积分布函数差异"""
        try:
            detector = KSDrift(ref_data, p_val=0.05, preprocess_fn=None)
            pred = detector.predict(current_data)
            return self._normalize_distance(np.mean(pred['data']['distance']), 'ks')
        except:
            logging.error("KS检测失败")
            return 0

    def _calculate_lsdd_drift(self, ref_data, current_data):
        """LSDD：最小二乘密度差异检测"""
        try:
            detector = LSDDDrift(ref_data, p_val=0.05, backend='pytorch', preprocess_fn=None)
            pred = detector.predict(current_data)
            return self._normalize_distance(np.mean(pred['data']['distance']), 'lsdd')
        except:
            logging.error("LSDD检测失败")
            return 0

    def _calculate_iforest_drift(self, ref_data, current_data):
        """孤立森林：训练于参考数据，检测当前数据中的异常比例作为漂移指标"""
        try:
            clf = IsolationForest(n_estimators=100, contamination='auto', random_state=42, max_samples='auto')
            clf.fit(ref_data)
            
            anomaly_scores = -clf.score_samples(current_data)
            print("异常分数:", anomaly_scores)

            # 计算异常分数>0.5的比例
            threshold = 0.5
            above_threshold = np.sum(anomaly_scores > threshold)
            percentage = float(above_threshold / len(anomaly_scores))
            print(f"异常分数>0.5的比例: {percentage:.2%}")
            return percentage

        except Exception as e:
            logging.error(f"Isolation Forest检测失败: {str(e)}", exc_info=True)
            return 0.0

    def _normalize_distance(self, distance, method):
        """距离归一化到[0, 1]范围"""
        return min(distance, 1.0)

    def _update_drift_history(self, drift_result):
        """更新漂移历史记录"""
        self.drift_history['wasserstein'].append(drift_result['wasserstein'])
        self.drift_history['ks'].append(drift_result['ks'])
        self.drift_history['lsdd'].append(drift_result['lsdd'])
        self.drift_history['iforest'].append(drift_result['iforest'])
        self.drift_history['timestamps'].append(datetime.now().strftime("%m-%d %H:%M"))
        print(f"历史记录更新完成,ks记录: {self.drift_history['ks']}")

    # ==================== 模型训练模块 ====================

    def train_model(self):
        """
        模型训练流程：
        1. 使用离线模型（最早的）预测新数据
        2. 使用在线模型（最新的）预测新数据
        3. 使用漂移检测模型预测新数据
        4. 训练新模型并入库
        5. 如检测到漂移，更新参考数据
        """
        if len(self.data_window) < self.window_size - 1:
            logger.warning("Not enough data for training")
            return

        self.data_window = self.data_window.sort_index(axis=1)

        # 查询数据库中的模型
        df = self.db_handler.query_model_data(
            ope_no=self.layer_info["ope_no"],
            tool_type=self.layer_info['tool_type'],
            recipe_short=self.layer_info['recipe_short'],
            product_id=self.layer_info['product_id'],
            fab_id=self.layer_info['fab_id'],
            dcitem=self.layer_info['dcitem'],
            model_version=self.config["model_version"]
        )
        df = df.sort_values("UPDATE_TIME", ascending=False)
        
        # ===== 离线模型（最早的模型）预测 =====
        logger.info("使用离线模型预测新到的片")
        offline_record = df[df['UPDATE_TIME'] == df["UPDATE_TIME"].min()]
        logger.info(f"离线模型的入库时间：{offline_record['UPDATE_TIME'].values[0]}")
        
        offline_model = pickle.loads(offline_record['MODEL'].values[0])
        offline_x_mean_std = pickle.loads(offline_record['NORM_PARAM'].values[0])
        test_data = align_old_model_with_feature(offline_model, self.data_window[-self.batch_size:].copy(), offline_x_mean_std)

        metrics_old, old_wafer_id, old_real, old_pre, test_feat, test_y_bias = model_predict(
            model=offline_model, data=test_data, standardization=offline_x_mean_std,
            list_category=self.list_category, target=self.target
        )
        
        self.offline_model_predict_value.extend(old_pre)
        self.y_true.extend(old_real)
        self.online_wafer_ids.extend(old_wafer_id)
        self.offline_model_predict_r2.append(metrics_old['r2'])
        logger.info(f"当前数据库中的离线模型预测R²：{metrics_old['r2']}")

        # ===== 在线模型（最新的模型）预测 =====
        logger.info("使用最新模型预测新到的片")
        latest_record = df[df['UPDATE_TIME'] == df["UPDATE_TIME"].max()]
        logger.info(f"当前最新模型入库时间：{latest_record['UPDATE_TIME'].values[0]}")
        
        newest_model = pickle.loads(latest_record['MODEL'].values[0])
        newest_x_mean_std = pickle.loads(latest_record['NORM_PARAM'].values[0])
        test_data = align_old_model_with_feature(newest_model, self.data_window[-self.batch_size:].copy(), newest_x_mean_std)

        metrics_newest, newest_wafer_id, newest_real, newest_pre, test_feat, test_y_bias = model_predict(
            model=newest_model, data=test_data, standardization=newest_x_mean_std,
            list_category=self.list_category, target=self.target
        )

        self.actual_model_predict_value.extend(newest_pre)
        self.actual_model_predict_r2.append(metrics_newest['r2'])
        logger.info(f"当前数据库中的最新模型预测R²：{metrics_newest['r2']}")

        # ===== 漂移检测模型预测 =====
        # first_drift_flag=True时使用1.1版本，False时使用1.2版本
        model_version = '1.1' if self.first_drift_flag else '1.2'
        time_selection = 'min' if self.first_drift_flag else 'max'

        df = self.db_handler.query_model_data(
            ope_no=self.layer_info["ope_no"],
            tool_type=self.layer_info['tool_type'],
            recipe_short=self.layer_info['recipe_short'],
            product_id=self.layer_info['product_id'],
            fab_id=self.layer_info['fab_id'],
            dcitem=self.layer_info['dcitem'],
            model_version=model_version
        ).sort_values("UPDATE_TIME", ascending=False)

        logger.info("漂移检测模型预测新到的片")

        if time_selection == 'min':
            drift_record = df[df['UPDATE_TIME'] == df["UPDATE_TIME"].min()]
        else:
            drift_record = df[df['UPDATE_TIME'] == df["UPDATE_TIME"].max()]

        logger.info(f"漂移模型的入库时间：{drift_record['UPDATE_TIME'].values[0]}")
        
        drift_model = pickle.loads(drift_record['MODEL'].values[0])
        drift_x_mean_std = pickle.loads(drift_record['NORM_PARAM'].values[0])
        test_data = align_old_model_with_feature(drift_model, self.data_window[-self.batch_size:].copy(), drift_x_mean_std)

        metrics_drift, drift_wafer_id, drift_real, drift_pre, test_feat, test_y_bias = model_predict(
            model=drift_model, data=test_data, standardization=drift_x_mean_std,
            list_category=self.list_category, target=self.target
        )

        self.drift_model_predict_value.extend(drift_pre)
        self.r2_history_drift.append(metrics_drift['r2'])
        logger.info(f"当前数据库中的漂移检测最新模型预测R²：{metrics_drift['r2']}")

        # 保存R²历史记录
        result_df = pd.DataFrame()
        result_df['offline_model_predict_r2'] = self.offline_model_predict_r2
        result_df['r2_history_drift'] = self.r2_history_drift
        result_df['actual_model_predict_r2'] = self.actual_model_predict_r2
        result_df['ks_drift_history'] = self.drift_history['ks']
        result_df.to_csv(f"r2_history_compare_{self.drift_threshold}.csv", index=None)

        # 保存预测值历史记录
        result_df = pd.DataFrame()
        result_df['online_wafer_ids'] = self.online_wafer_ids
        result_df['y_true'] = self.y_true
        result_df['offline_model_predict_value'] = self.offline_model_predict_value
        result_df['drift_model_predict_value'] = self.drift_model_predict_value
        result_df['actual_model_predict_value'] = self.actual_model_predict_value
        result_df.to_csv(f"pred_history_compare_{self.drift_threshold}.csv", index=None)

        # ===== 训练新模型 =====
        train_set, test_set = split_dataset(self.data_window[:-self.batch_size], self.data_window[-self.batch_size:])

        model, x_mean_std, confidence_param, update_flag, metrics_new = getBestModel(
            train_set, test_set,
            target=self.target,
            k_fold=self.k_fold,
            list_category=self.list_category,
            old_model=newest_model,
            fix_feature=self.fix_feature,
            model_param=self.model_param
        )

        confidence_param |= metrics_new

        # 模型序列化并入库
        model_bytes = pickle.dumps(model)
        x_mean_std = pickle.dumps(x_mean_std)
        confidence_param = pickle.dumps(confidence_param)
        
        self.layer_info["model"] = model_bytes
        self.layer_info["norm_param"] = x_mean_std
        self.layer_info["category_encoder"] = confidence_param
        self.layer_info["debug_info"] = confidence_param
        self.layer_info["version"] = '10.1'
        
        self.db_handler.insert_model_data(**self.layer_info)
        logger.info("模型入库成功")

        logger.info(f"离线r2记录{len(self.offline_model_predict_r2)}{self.offline_model_predict_r2}")
        logger.info(f"在线r2记录{len(self.actual_model_predict_r2)}{self.actual_model_predict_r2}")
        logger.info(f"漂移检测r2记录{len(self.r2_history_drift)}{self.r2_history_drift}")
        logger.info(f"漂移检测记录{len(self.drift_history['timestamps'])}{self.drift_history}")

        # 如检测到漂移，更新参考数据并存储漂移版本模型
        if self.force_update:
            self.preprocessed_reference = self.processed_current
            print("参考数据已更新")
            self.first_drift_flag = False
            
            self.layer_info["model"] = model_bytes
            self.layer_info["norm_param"] = x_mean_std
            self.layer_info["category_encoder"] = confidence_param
            self.layer_info["debug_info"] = confidence_param
            self.layer_info["version"] = '1.2'
            
            self.db_handler.insert_model_data(**self.layer_info)
            logger.info("模型入库成功")
        else:
            ...
            
        logger.info("模型训练完成")

    def monitor_and_train(self, config):
        """
        定时执行的主逻辑（由APScheduler调用）
        
        流程：拉取新数据 → 更新窗口 → 漂移检测 → 模型训练
        """
        try:
            new_data = self.fetch_new_data(
                config["siteID"], config["tool_type"], config["recipe_short"],
                config["product_id"], config["fab_id"], config["metParamID"],
                config["metID"], config["train_size"], config["buffer_threshold"],
                config["test_online"], config["pre_process"], config["model_version"]
            )
            
            if not new_data.empty:
                self.new_data_length += new_data.shape[0]
                self.last_check_time = new_data["update_time"].max()
            self.update_data_window(new_data)

            # 累积数据量达到阈值时执行训练
            if self.new_data_length >= self.batch_size:
                data_window_copy = self.data_window.copy()
                cols_to_drop = ["wafer_id", "update_time", "gt"]
                existing_cols = data_window_copy.columns.intersection(cols_to_drop).tolist()

                if existing_cols:
                    current_features = data_window_copy.drop(columns=existing_cols)
                else:
                    current_features = data_window_copy

                feature_names = [f for f in current_features.columns if f not in self.list_category]
                logger.info(f"过滤后的特征数量: {len(feature_names)}")

                # 漂移检测
                drift_result = self.calculate_feature_drift(current_features, feature_names, self.fixed_ref)
                logger.info(
                    f"Drift检测结果 - Wasserstein: {drift_result['wasserstein']:.3f}, "
                    f"KS: {drift_result['ks']:.3f}, LSDD: {drift_result['lsdd']:.3f}, "
                    f"iforest: {drift_result['iforest']:.3f}"
                )

                self.force_update = drift_result["status"] == "drift"
                self.train_model()
                self.is_first_run = False

        except Exception as e:
            logger.error(traceback.format_exc())
            logger.error(f"Error in monitoring job: {str(e)}")

    def shutdown(self):
        """关闭后台调度器"""
        self.scheduler.shutdown()


# ==================== 主程序入口 ====================

if __name__ == "__main__":
    import time

    parser = argparse.ArgumentParser(description='开发/生产环境切换')
    # TODO: 部署时记得切换测试环境
    parser.add_argument('--TLF_TEST', type=str, help='<DEV>/<PROD>', default="TLF_TEST")
    args = parser.parse_args()
    
    # 加载配置
    config = load_yaml(r'/config/config.yaml')
    args.env = args.TLF_TEST.upper()
    env_args = config[args.env]
    db_config = env_args["db_info"]
    config = config["COMMON"]
    
    # 提取配置项
    list_category = config['list_category']
    model_config = config['model_param']
    logger_path = config['logger_path']
    buffer_threshold = config['buffer_threshold']
    train_size = config['train_size']

    # 层级信息
    ope_no = config['siteID']
    tool_type = config['tool_type']
    recipe_short = config['recipe_short']
    product_id = config["product_id"]
    fab_id = config["fab_id"]
    dcitem = config['metParamID']
    met_no = config['metID']
    k_fold = config['k_fold']
    target = config['target']
    layer_name = config['layer_name']
    model_param = config['model_param']
    fix_feature_flag = config['fix_feature_flag']
    interval = env_args['interval']
    pre_process = config['pre_process']
    
    layer_info = {
        "ope_no": ope_no, "product_id": product_id, "fab_id": fab_id,
        "dcitem": dcitem, "tool_type": tool_type, "recipe_short": recipe_short,
        "layer": layer_name, "version": config["model_version"]
    }
    
    logger = configure_logger(log_file=f'{logger_path}')
    
    monitor = DataMonitorAndTrainer(
        config, db_config=db_config, window_size=train_size, batch_size=buffer_threshold,
        interval=interval, k_fold=k_fold, target=target, list_category=list_category,
        layer_info=layer_info, fix_feature_flag=fix_feature_flag, model_param=model_param,
        last_check_time=datetime(2023, 1, 1, 0, 0, 0)
    )

    logger.info("Monitoring started. Press Ctrl+C to stop.")
    
    try:
        while True:
            time.sleep(1)
    except (KeyboardInterrupt, SystemExit):
        monitor.shutdown()
